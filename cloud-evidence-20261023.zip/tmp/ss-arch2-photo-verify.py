from pathlib import Path
import re, subprocess, json
root=Path('/workspace/ss-arch1')
base=subprocess.check_output(['git','show','3afb12f966efc2646c9b148ddf7de5aafe68c5c5:game/src/main.gd'],cwd=root,text=True)
main=(root/'game/src/main.gd').read_text();module=(root/'game/src/presentation/flow/photo_review.gd').read_text()
def blocks(s):
 lines=s.splitlines(keepends=True);out={}
 for i,line in enumerate(lines):
  m=re.match(r'(?:static )?func (\w+)\((.*)\)(.*):\n$',line)
  if not m:continue
  end=i+1
  while end<len(lines) and (not lines[end].strip() or lines[end][0].isspace()):end+=1
  out[m[1]]=(i,end,line,''.join(lines[i+1:end]),m[2],m[3])
 return lines,out
old_lines,old=blocks(base);new_lines,new=blocks(main);_,flow=blocks(module)
assert len(flow)==9 and set(old)==set(new)
replacements=[]
for method,(_,_,_,body,args,ret) in flow.items():
 name='_reference' if method=='show_reference' else '_'+method
 assert name in old
 restored=body.replace('host.','');restored=re.sub(r'\bhost\b','self',restored).replace('var learned:String=_shot_findings(', 'var learned:=_shot_findings(')
 assert restored.rstrip()==old[name][3].rstrip(),name
 assert new[name][2]==old[name][2],name
 params=[re.match(r'\s*(\w+)',a)[1] for a in old[name][4].split(',') if a.strip()]
 expected=('return ' if not re.search(r'->\s*void\s*$',ret) else '')+'PhotoReview.'+method+'(self'+(', '+', '.join(params) if params else '')+')'
 assert new[name][3].strip()==expected,name
 replacements.append((new[name][0],new[name][1],old[name][2]+old[name][3]))
for start,end,text in sorted(replacements,reverse=True):new_lines[start:end]=[text]
reassembled=''.join(new_lines).replace('const PhotoReview=preload("res://src/presentation/flow/photo_review.gd")\n','',1)
assert reassembled==base,'whole main restoration'
proof={'base':'3afb12f966efc2646c9b148ddf7de5aafe68c5c5','functions':len(flow),'moved_body_parity':True,'explicit_type':'learned retains original inferred String','main_forwarders':True,'whole_main_restoration':True,'rules_numbers_and_text':'identical in every moved body','test_sources':'unchanged'}
print(json.dumps(proof,indent=2))
