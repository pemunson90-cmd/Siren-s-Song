from pathlib import Path
import re, subprocess, json
root=Path('/workspace/ss-photo')
source=subprocess.check_output(['git','show','b03dd691a4775bbc07abfa1e87f4938ead653342:game/src/main.gd'],cwd=root,text=True)
names=['_loadout_stock','_show_campaign','_campaign_pristine','_show_fittings','_cycle_loadout','_orders_text','_briefing','_fold_fit','_reference','_launch_context','_equipment_entitlements','_campaign_completed','_equipment_context','_choose_equipment','_debrief','_sync_craft_upgrades','_show_ending','_confirm_new_campaign','_new_campaign']
members=set(re.findall(r'^(?:var|const|func)\s+(\w+)',source,re.M))|{'size','call_deferred','get_tree','get_window','get_viewport_rect','get_node_or_null'}
token=re.compile(r'''"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|\#[^\n]*|\b[A-Za-z_]\w*\b''')
def qualify(body):
 def one(m):
  value=m.group()
  if value[0] in "\"'#":return value
  if value=='self':return 'host'
  if value in members and not body[:m.start()].rstrip(' \t').endswith('.'):return 'host.'+value
  return value
 return token.sub(one,body)
lines=source.splitlines(keepends=True);blocks=[]
for i,line in enumerate(lines):
 m=re.match(r'func (\w+)\((.*)\)(.*):\n$',line)
 if not m or m[1] not in names:continue
 end=i+1
 while end<len(lines) and (not lines[end].strip() or lines[end][0].isspace()):end+=1
 args=m[2]; params=[re.match(r'\s*(\w+)',a)[1] for a in args.split(',') if a.strip()]
 flow_name='show_reference' if m[1]=='_reference' else m[1][1:]
 signature='static func '+flow_name+'(host'+(', '+args if args else '')+')'+m[3]+':\n'
 body=''.join(lines[i+1:end]); moved=qualify(body)
 prefix='return ' if not re.search(r'->\s*void\s*$',m[3]) else ''
 wrapper=line+'\t'+prefix+'CampaignFlow.'+flow_name+'(self'+(', '+', '.join(params) if params else '')+')\n'
 blocks.append((i,end,m[1],signature+moved,wrapper,body,moved))
assert len(blocks)==len(names)
header='''extends RefCounted
# Campaign/menu flow extracted verbatim from main. Main keeps its existing
# entry points as forwarders; host owns state, callbacks and deferred layout.
# Revert this PR to restore the bodies in main. No rules, text or save changes.
'''
module=header+'\n'.join(b[3] for b in blocks)
for i,end,name,moved,wrapper,body,qualified in reversed(blocks):lines[i:end]=[wrapper]
main=''.join(lines).replace('extends Control\n','extends Control\nconst CampaignFlow=preload("res://src/presentation/flow/campaign_flow.gd")\n',1)
# Exact reverse qualification proves every moved body preserves its text/tokens.
for _,_,name,_,_,body,qualified in blocks:
 def reverse(m):
  v=m.group()
  if v[0] in "\"'#":return v
  return 'self' if v=='host' else v
 unqualified=re.sub(r'\bhost\.(?=\w)', '', qualified)
 # No string or comment in these original bodies contains the host qualifier.
 unqualified=token.sub(reverse,unqualified)
 assert unqualified==body,name
path=root/'game/src/presentation/flow';path.mkdir(parents=True,exist_ok=True)
(path/'campaign_flow.gd').write_text(module)
(root/'game/src/main.gd').write_text(main)
print(json.dumps({'functions':len(blocks),'names':[b[2] for b in blocks],'body_parity':'exact after host qualification','main_lines_before':len(source.splitlines()),'main_lines_after':len(main.splitlines()),'module_lines':len(module.splitlines())}))
