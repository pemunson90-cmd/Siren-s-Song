extends "res://tests/t_pressure_probes.gd"
# External diagnostic driver only. No simulation state or tracked test changes.
# Match the inherited tick epsilon to avoid its budget-boundary busy loop.
func running() -> bool:
 return sim.outcome.is_empty() and sim.elapsed + .00001 < BUDGET and stop_reason.is_empty()
func run_probe(id:int,name:String):
 super.run_probe(id,name)
 if sim.outcome.is_empty() and sim.elapsed + .00001 >= BUDGET:
  row.outcome="budget_timeout"
  rows[-1]=row.duplicate(true)
  FileAccess.open(out_dir+"/op_%02d_%s.json"%[id,name],FileAccess.WRITE).store_string(JSON.stringify(row,"\t"))
