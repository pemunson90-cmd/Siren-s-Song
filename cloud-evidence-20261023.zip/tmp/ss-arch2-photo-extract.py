from pathlib import Path
import re, subprocess, json
root=Path('/workspace/ss-arch1')
source=subprocess.check_output(['git','show','3afb12f966efc2646c9b148ddf7de5aafe68c5c5:game/src/main.gd'],cwd=root,text=True)
names=['_show_photo_grade','_merge_shots','_evidence_is_text','_retain_evidence','_evidence_gallery','_shot_report','_shot_findings','_shot_difference','_intel_screen']
members=set(re.findall(r'^(?:var|const|func)\s+(\w+)',source,re.M))|{'size','call_deferred','get_tree','get_window','get_viewport_rect','get_node_or_null'}
token=re.compile(r'''"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|\#[^\n]*|\b[A-Za-z_]\w*\b''')
def qualify(body):
 def one(m):
  value=m.group()
  if value[0] in "\"'#":return value
  if value=='self':return 'host'
  if value in members and not body[:m.start()].rstrip(' \t').endswith('.'):return 'host.'+value
  return value
 return token.sub(one,body)
lines=source.splitlines(keepends=True);blocks=[]
for i,line in enumerate(lines):
 m=re.match(r'func (\w+)\((.*)\)(.*):\n$',line)
 if not m or m[1] not in names:continue
 end=i+1
 while end<len(lines) and (not lines[end].strip() or lines[end][0].isspace()):end+=1
 args=m[2]; params=[re.match(r'\s*(\w+)',a)[1] for a in args.split(',') if a.strip()]
 flow_name='show_reference' if m[1]=='_reference' else m[1][1:]
 signature='static func '+flow_name+'(host'+(', '+args if args else '')+')'+m[3]+':\n'
 body=''.join(lines[i+1:end]); moved=qualify(body).replace("var learned:=host._shot_findings(", "var learned:String=host._shot_findings(")
 prefix='return ' if not re.search(r'->\s*void\s*$',m[3]) else ''
 wrapper=line+'\t'+prefix+'PhotoReview.'+flow_name+'(self'+(', '+', '.join(params) if params else '')+')\n'
 blocks.append((i,end,m[1],signature+moved,wrapper,body,moved))
assert len(blocks)==len(names)
header='''extends RefCounted
# Photograph and archive review extracted from main. Main keeps its existing
# entry points as forwarders; host owns state, callbacks and deferred layout.
# Revert this PR to restore the bodies in main. No rules, text or save changes.
'''
module=header+'\n'.join(b[3] for b in blocks)
for i,end,name,moved,wrapper,body,qualified in reversed(blocks):lines[i:end]=[wrapper]
main=''.join(lines).replace('extends Control\n','extends Control\nconst PhotoReview=preload("res://src/presentation/flow/photo_review.gd")\n',1)
# Exact reverse qualification proves every moved body preserves its text/tokens.
for _,_,name,_,_,body,qualified in blocks:
 def reverse(m):
  v=m.group()
  if v[0] in "\"'#":return v
  return 'self' if v=='host' else v
 unqualified=re.sub(r'\bhost\.(?=\w)', '', qualified)
 # No string or comment in these original bodies contains the host qualifier.
 unqualified=token.sub(reverse,unqualified).replace("var learned:String=_shot_findings(", "var learned:=_shot_findings(")
 assert unqualified==body,name
path=root/'game/src/presentation/flow';path.mkdir(parents=True,exist_ok=True)
(path/'photo_review.gd').write_text(module)
(root/'game/src/main.gd').write_text(main)
print(json.dumps({'functions':len(blocks),'names':[b[2] for b in blocks],'body_parity':'exact after host qualification','main_lines_before':len(source.splitlines()),'main_lines_after':len(main.splitlines()),'module_lines':len(module.splitlines())}))
