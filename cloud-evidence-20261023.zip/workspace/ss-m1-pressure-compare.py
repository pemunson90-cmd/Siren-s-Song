import collections,hashlib,json,pathlib
root=pathlib.Path('/workspace')
paths=[root/'ss-m1-pressure-before/rows.json',root/'ss-m1-pressure-after/rows.json']
if not all(p.exists() for p in paths):
 print('Pressure comparison waits for both complete row aggregates.')
 raise SystemExit(2)
sets=[json.loads(p.read_text()) for p in paths]
indexed=[{(r['operation'],r['policy']):r for r in rows} for rows in sets]
assert all(len(rows)==76 and len(index)==76 for rows,index in zip(sets,indexed))
assert indexed[0].keys()==indexed[1].keys()
diffs=[]
for key,left in indexed[0].items():
 right=indexed[1][key]
 for field in left.keys()|right.keys():
  if left.get(field)!=right.get(field):
   diffs.append({'operation':key[0],'policy':key[1],'field':field,'before':left.get(field),'after':right.get(field)})
report={'before_sha':'1b7e233be6c63fd5bac24c7486d69d2e2f130020','after_sha':'5e6ada5a927c2e0d67b773712cd1cbb0a01a9509','pairs':76,'all_fields_identical':not diffs,'differences':diffs,'all_snapshots_valid':all(r['snapshot_valid'] for rows in sets for r in rows),'outcomes':[dict(collections.Counter(r['outcome'] for r in rows)) for rows in sets],'commands':[sum(len(r['commands']) for r in rows) for rows in sets],'driver_sha256':hashlib.sha256(pathlib.Path('/tmp/ss-m1-pressure-bounded.gd').read_bytes()).hexdigest(),'driver_scope':'External probe only: inherited tick epsilon prevents budget-boundary busy loop; budget-end cases classified as timeouts. No simulation writes beyond inherited initial scenario/policy.'}
(root/'ss-m1-pressure-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='differences'},indent=2))
assert not diffs and report['all_snapshots_valid'], 'Pressure comparison failed'
