extends SceneTree
var checks=0
var failures=0
func check(ok,label):
	checks+=1
	if not ok:failures+=1;printerr("FAIL: ",label)
func _initialize():call_deferred("run")
func run():
	root.size=Vector2i(1280,720);await process_frame;await process_frame
	var game=load("res://proto/main.tscn").instantiate();root.add_child(game)
	await process_frame;await process_frame
	game.set_process(false)
	check(game.sim.has_method("exchange_context") and game.mission_index==2,"playable entry starts isolated Blackwater model")
	check(game.order_buttons.camera.text=="SAMPLE","experimental action is visibly hydrophone SAMPLE")
	game._enter_water();check(game.screen=="mission" and game.menu.visible==false,"comparison menu resumes actual route controls")
	game.sim.units[0].pos=Vector2(760,330);game.sim.command("camera");game.sim.paused=false
	for n in 60:game.sim.advance(1.0/60)
	game.sim.paused=true
	game.store.path="user://blackwater-ui-test.save";game.capture_scenario="";game._save_archive()
	var data=game.store.load_game();var other=load("res://proto/simulation.gd").new()
	check(not data.is_empty() and other.restore(data.active),"ordinary archive stores/restores experimental mission without touching production saves")
	check(other.exchange.site==0 and other.exchange.progress>0.9 and other.paused,"restore preserves partial reception and tactical pause")
	var before=other.snapshot();other.advance(20);check(before==other.snapshot(),"restored pause prevents clock/replay/progress drift")
	game.exchange_mode="baseline";game._start_mission(2);check(game.order_buttons.camera.text=="CAMERA" and game.sim.mission.objectives[0].get("kind","")!="exchange","same playable entry retains unchanged optical baseline")
	game.exchange_mode="direct";game._start_mission(2);check(game.sim.variant=="direct","comparison restart selects simpler no-window model")
	game.queue_free();await process_frame;await process_frame;await process_frame
	print("EXCHANGE PLAYABLE CHECKS ",checks," FAILURES ",failures);quit(1 if failures else 0)
