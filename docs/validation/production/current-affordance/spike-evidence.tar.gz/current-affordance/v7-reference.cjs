const fs=require('fs'),vm=require('vm'),crypto=require('crypto');
const file='reference/original-prototype/sirens_song_prototype_v7.html',source=fs.readFileSync(file,'utf8');
const cfg=source.match(/const CFG=(\{[\s\S]*?\n\});/)[0];
const fn=source.slice(source.indexOf('function updateSub(dt){'),source.indexOf('function updateFX(dt){'));
const context={WORLD_W:1200,WORLD_H:1800,obstacles:[],dist:(a,b)=>Math.hypot(a.x-b.x,a.y-b.y),currents:[]};
vm.createContext(context);vm.runInContext(cfg+fn,context);
const samples=[];
for(const offset of [0,100,200]){
 context.sub={x:700+offset,y:820,tx:700+offset,ty:820,silent:true,spd:0,h:0};
 context.currents=[{x:700,y:820,r:200,fx:34,fy:-10}];
 vm.runInContext('updateSub(0.5)',context);
 samples.push({offset,dt:0.5,displacement:[context.sub.x-(700+offset),context.sub.y-820],propulsion_speed:context.sub.spd});
}
fs.writeFileSync('work/current-affordance/v7-reference.json',JSON.stringify({source:file,sha256:crypto.createHash('sha256').update(source).digest('hex'),method:'Actual CFG/updateSub extracted verbatim, Node vm; isolated unobstructed mechanical fixture, not browser/human play',samples},null,2)+'\n');
