from pathlib import Path
source=Path('game/src/simulation/simulation.gd').read_text()
move=source[source.index('func _move('):source.index('func _observe()')]
move=move.replace('\tvar desired=Vector2.ZERO','''	if not flow_enabled:
		super._move(u,dt,speed,holding,report_collision,player_craft);return
	var flow=water_at(u.pos)
	if flow==Vector2.ZERO and not u.has("flow_station"):
		super._move(u,dt,speed,holding,report_collision,player_craft);return
	if holding and not u.has("flow_station"):u.flow_station=u.pos
	if not holding and not u.route.is_empty():u.erase("flow_station")
	var desired=flow if u.route.is_empty() and not u.has("flow_station") else Vector2.ZERO''')
old='''			if dest.stop and u.vel.length()>2:
				u.vel=u.vel.move_toward(Vector2.ZERO,100*dt)
				var braking:Vector2=u.pos+u.vel*dt
				if not blocked(braking,12): u.pos=braking
				return'''
new='''			if dest.stop and ground_velocity(u).length()>2:
				_push(u,dt,(dest.pos-u.pos).limit_length(4.0),flow,speed,report_collision,player_craft)
				return
			if dest.stop and u.route.size()==1:u.flow_station=dest.pos'''
assert old in move
move=move.replace(old,new).replace('u.vel.length_squared()/84.0','ground_velocity(u).length_squared()/84.0')
move=move.replace('''			u.angle=rotate_toward(u.angle,target_angle,1.8*dt)
			desired=Vector2.from_angle(u.angle)*target_speed''','''			desired=delta.normalized()*target_speed
			# Course commands retain their through-water thrust request. Cancel
			# sideways flow only; favorable/adverse axial flow changes progress.
			# Near STOP, request ground braking instead, preserving arrival intent.
			var ground_braking=u.route[0].stop and delta.length()<12.0+ground_velocity(u).length_squared()/70.0
			if not ground_braking:desired+=flow.project(delta.normalized())''')
start=move.index('\tu.vel=u.vel.move_toward(desired,42*dt)')
move=move[:start]+'''	if (holding or u.route.is_empty()) and u.has("flow_station"):
		desired=((u.flow_station-u.pos)*2.0).limit_length(12.0)
	_push(u,dt,desired,flow,speed,report_collision,player_craft)
'''
head='''extends "res://src/simulation/simulation.gd"
# THROWAWAY CURRENT CONTRACT: authored fixture only, never product metadata.
# u.vel remains through-water propulsion; positions integrate propulsion+flow.
var flow_enabled=true
var center=Vector2(700,820)
var radius=160.0
var peak=Vector2(34,-10)
func install_lane()->void:
	mission["prototype_flow"]={"center":center,"radius":radius,"peak":peak}
func water_at(p:Vector2)->Vector2:
	if not flow_enabled or not mission.has("prototype_flow"):return Vector2.ZERO
	var f=mission.prototype_flow
	return f.peak*maxf(0.0,1.0-p.distance_to(f.center)/f.radius)
func ground_velocity(u:Dictionary)->Vector2:
	return u.vel+water_at(u.pos)
func command(order:String,args:Dictionary={})->bool:
	var result=super.command(order,args)
	if result and order in ["route","emergency","hold","contact_hold","wait_drone"]:units[selected].erase("flow_station")
	return result
func blackwater_context(target:int,station:int=-1)->Dictionary:
	var result=super.blackwater_context(target,station)
	if station<0:station=selected
	result.settled=ground_velocity(units[station]).length()<2.0
	return result
func _push(u:Dictionary,dt:float,ground_desired:Vector2,flow:Vector2,speed:float,report_collision:bool,player_craft:bool)->void:
	var water_desired=(ground_desired-flow).limit_length(speed)
	if water_desired.length()>0.01:
		u.angle=rotate_toward(u.angle,water_desired.angle(),1.8*dt)
		water_desired=Vector2.from_angle(u.angle)*water_desired.length()
	u.vel=u.vel.move_toward(water_desired,42.0*dt)
	var next:Vector2=u.pos+(u.vel+flow)*dt
	if not blocked(next,12) and segment_safe(u.pos,next,12):u.pos=next
	else:
		u.vel=Vector2.ZERO;u.route.clear();u.erase("flow_station")
		if player_craft:RouteProgram.clear(u)
		if report_collision:message="Flow/terrain clearance stopped course · replot or hold away from rock"
'''
Path('work/current-affordance/flow_sim.gd').write_text(head+move)
