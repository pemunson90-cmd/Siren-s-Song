extends SceneTree
const Base=preload("res://src/simulation/simulation.gd")
var Flow=load("/workspace/Siren-s-Song-drone-investigation/work/current-affordance/flow_sim.gd")
var failures=0
func check(ok:bool,label:String):
	print("PASS " if ok else "FAIL ",label)
	if not ok:failures+=1
func fixture(hold:bool):
	var s=Flow.new();s.start(0);s.install_lane();s.units[0].pos=Vector2(700,820);s.units[0].angle=0.0
	if hold:s.command("hold")
	s.paused=false;return s
func _initialize():
	var drift=fixture(false);var initial:Vector2=drift.units[0].pos
	for i in 20:drift.advance(0.1)
	check(drift.units[0].pos.distance_to(initial)>40 and drift.units[0].vel.length()<0.01,"passive current transports hull without inventing propulsion/noise")
	var hold=fixture(true);var anchor:Vector2=hold.units[0].pos;var peak_error=0.0
	for i in 160:hold.advance(0.1);peak_error=maxf(peak_error,hold.units[0].pos.distance_to(anchor))
	check(hold.ground_velocity(hold.units[0]).length()<2 and hold.units[0].pos.distance_to(anchor)<4,"HOLD physically converges to ground station")
	check(hold.units[0].vel.length()>20 and hold.acoustic_feedback().motion.size()>0 and peak_error>1,"counterthrust makes real motion noise and retains transient drift")
	var stop=fixture(false);stop.command("route",{"point":Vector2(780,800)})
	for i in 180:stop.advance(0.1)
	check(stop.units[0].route.is_empty() and stop.units[0].pos.distance_to(Vector2(780,800))<9 and stop.ground_velocity(stop.units[0]).length()<2,"finalSTOP reaches a ground stop and remains at its destination")
	var frozen=hold.snapshot();hold.paused=true;frozen=hold.snapshot();hold.advance(2);check(hold.snapshot()==frozen,"pause freezes drift and compensation")
	var plain=Base.new();plain.start(0);plain.command("route",{"point":Vector2(350,800)});plain.paused=false
	var off=Flow.new();off.flow_enabled=false;off.start(0);off.command("route",{"point":Vector2(350,800)});off.paused=false
	for i in 80:plain.advance(0.1);off.advance(0.1)
	check(plain.snapshot()==off.snapshot(),"no-field legacy movement/state remains exact")
	var receiver=Flow.new();receiver.start(2);receiver.center=Vector2(760,200);receiver.install_lane();receiver.units[0].pos=receiver.center
	check(not receiver.blackwater_context(0,0).settled,"zero propulsion while drifting does not falsely settle a receiver")
	receiver.units[0].vel=-receiver.water_at(receiver.units[0].pos)
	check(receiver.blackwater_context(0,0).settled and not receiver.acoustic_feedback().motion.is_empty(),"ground-settled counterthrust receiver remains acoustically active")
	var restored=Flow.new();check(restored.restore(hold.snapshot()) and restored.units[0].has("flow_station") and restored.water_at(restored.units[0].pos).length()>0,"fixture save retains commanded station and authored flow; restore paused")
	var legacy=Flow.new();check(legacy.restore(plain.snapshot()) and legacy.water_at(Vector2(700,820))==Vector2.ZERO,"legacy snapshot without authored fixture gets no retroactive flow")
	var collision=fixture(false);collision.units[0].pos=Vector2(415,480);collision.center=Vector2(415,480);collision.peak=Vector2(34,0);collision.install_lane()
	for i in 60:collision.advance(0.1)
	check(not collision.blocked(collision.units[0].pos,12),"current transport cannot penetrate terrain")
	var transit=fixture(false);transit.units[0].pos=Vector2(650,820);transit.command("route",{"point":Vector2(900,820)})
	var maximum_ground=0.0;var maximum_water=0.0
	for i in 100:
		transit.advance(0.1);maximum_ground=maxf(maximum_ground,transit.ground_velocity(transit.units[0]).length());maximum_water=maxf(maximum_water,transit.units[0].vel.length())
	check(maximum_ground>60 and maximum_water<=42.01,"along-course flow adds ground progress while preserving requested through-water cap")
	print("GUARDS failed=",failures);quit(1 if failures else 0)
