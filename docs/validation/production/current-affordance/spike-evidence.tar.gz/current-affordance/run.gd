extends SceneTree
const Base=preload("res://src/simulation/simulation.gd")
var Flow=load("/workspace/Siren-s-Song-drone-investigation/work/current-affordance/flow_sim.gd")
var artifact_dir="/workspace/Siren-s-Song-drone-investigation/work/current-affordance/"
func issue(s,commands:Array,order:String,args:Dictionary={}):
	var ok=s.command(order,args)
	var c={"t":s.elapsed,"order":order,"ok":ok}
	if args.has("point"):c.point=[args.point.x,args.point.y]
	commands.append(c);return ok
func sample(s)->Dictionary:
	var u=s.units[0];var water:Vector2=s.water_at(u.pos);var ground:Vector2=s.ground_velocity(u)
	return {"t":s.elapsed,"pos":[u.pos.x,u.pos.y],"water_velocity":[u.vel.x,u.vel.y],"ground_velocity":[ground.x,ground.y],"local_flow":[water.x,water.y],"engine_radius":s.Acoustics.motion_radius(u.vel.length()),"route":u.route.map(func(n):return [n.pos.x,n.pos.y]),"hold":u.hold,"station":u.has("flow_station"),"hull":s.hull,"oxygen":s.oxygen,"stock":s.tools.duplicate(),"record":s.all_records(),"contacts":s.contacts.values().map(func(c):return {"pos":[c.pos.x,c.pos.y],"time":c.time,"lock":c.lock})}
func trial(checkpoint:Dictionary,flow:bool,idle:bool)->void:
	var s=Flow.new();s.restore(checkpoint);s.flow_enabled=flow
	if flow:s.install_lane()
	var commands:Array=[];var samples:Array=[];var phase="approach";var departure=s.elapsed;var arrive=-1.0;var record=-1.0;var return_started=-1.0;var ground_distance=0.0;var engine_integral=0.0;var max_radius=0.0;var previous:Vector2=s.units[0].pos
	if not idle:
		issue(s,commands,"route",{"point":Vector2(900,800)})
		issue(s,commands,"queue");issue(s,commands,"route",{"point":Vector2(1300,500)});issue(s,commands,"queue")
	s.paused=false
	for n in 1400:
		s.advance(0.1)
		var u=s.units[0];ground_distance+=u.pos.distance_to(previous);previous=u.pos
		engine_integral+=u.vel.length()*0.1;max_radius=maxf(max_radius,s.Acoustics.motion_radius(u.vel.length()))
		if not idle:
			if phase=="approach" and u.route.is_empty() and u.pos.distance_to(Vector2(1300,500))<12 and s.ground_velocity(u).length()<2:
				arrive=s.elapsed;issue(s,commands,"camera");phase="exposure"
			if phase=="exposure" and s.all_records():
				record=s.elapsed;return_started=s.elapsed
				issue(s,commands,"route",{"point":Vector2(900,640)})
				issue(s,commands,"queue");issue(s,commands,"route",{"point":Vector2(350,640)});issue(s,commands,"route",{"point":s.mission.extraction});issue(s,commands,"queue");phase="return"
		if n%5==0:samples.append(sample(s))
		if not s.outcome.is_empty() or (idle and s.elapsed-departure>=20):break
	var last=sample(s)
	var summary={"flow":flow,"idle":idle,"checkpoint_elapsed":departure,"outcome":s.outcome,"total_elapsed":s.elapsed,"duration":s.elapsed-departure,"approach_duration":arrive-departure if arrive>0 else -1,"record_time":record,"return_duration":s.elapsed-return_started if return_started>0 else -1,"hull":s.hull,"oxygen":s.oxygen,"tools":s.tools,"alive":s.units.map(func(u):return u.alive),"ground_distance":ground_distance,"through_water_distance":engine_integral,"max_engine_radius":max_radius,"last":last}
	var label=("current" if flow else "baseline")+("-idle" if idle else "-policy")
	FileAccess.open(artifact_dir+label+".json",FileAccess.WRITE).store_string(JSON.stringify({"summary":summary,"commands":commands,"samples":samples},"\t"))
	print(JSON.stringify(summary))
func _initialize():
	var seed=Base.new();seed.start(0);var commands=[]
	issue(seed,commands,"route",{"point":Vector2(650,800)});seed.paused=false
	for i in 300:
		seed.advance(0.1)
		if seed.units[0].route.is_empty() and seed.units[0].vel.length()<0.1:break
	issue(seed,commands,"hold");seed.paused=true
	var checkpoint=seed.snapshot()
	FileAccess.open(artifact_dir+"earned-checkpoint.bin",FileAccess.WRITE).store_buffer(var_to_bytes(checkpoint))
	FileAccess.open(artifact_dir+"checkpoint-commands.json",FileAccess.WRITE).store_string(JSON.stringify(commands,"\t"))
	for flow in [false,true]:
		trial(checkpoint,flow,false);trial(checkpoint,flow,true)
	quit()
