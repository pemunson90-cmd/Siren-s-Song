extends "res://src/simulation/simulation.gd"
# THROWAWAY CURRENT CONTRACT: authored fixture only, never product metadata.
# u.vel remains through-water propulsion; positions integrate propulsion+flow.
var flow_enabled=true
var center=Vector2(700,820)
var radius=160.0
var peak=Vector2(34,-10)
func install_lane()->void:
	mission["prototype_flow"]={"center":center,"radius":radius,"peak":peak}
func water_at(p:Vector2)->Vector2:
	if not flow_enabled or not mission.has("prototype_flow"):return Vector2.ZERO
	var f=mission.prototype_flow
	return f.peak*maxf(0.0,1.0-p.distance_to(f.center)/f.radius)
func ground_velocity(u:Dictionary)->Vector2:
	return u.vel+water_at(u.pos)
func command(order:String,args:Dictionary={})->bool:
	var result=super.command(order,args)
	if result and order in ["route","emergency","hold","contact_hold","wait_drone"]:units[selected].erase("flow_station")
	return result
func blackwater_context(target:int,station:int=-1)->Dictionary:
	var result=super.blackwater_context(target,station)
	if station<0:station=selected
	result.settled=ground_velocity(units[station]).length()<2.0
	return result
func _push(u:Dictionary,dt:float,ground_desired:Vector2,flow:Vector2,speed:float,report_collision:bool,player_craft:bool)->void:
	var water_desired=(ground_desired-flow).limit_length(speed)
	if water_desired.length()>0.01:
		u.angle=rotate_toward(u.angle,water_desired.angle(),1.8*dt)
		water_desired=Vector2.from_angle(u.angle)*water_desired.length()
	u.vel=u.vel.move_toward(water_desired,42.0*dt)
	var next:Vector2=u.pos+(u.vel+flow)*dt
	if not blocked(next,12) and segment_safe(u.pos,next,12):u.pos=next
	else:
		u.vel=Vector2.ZERO;u.route.clear();u.erase("flow_station")
		if player_craft:RouteProgram.clear(u)
		if report_collision:message="Flow/terrain clearance stopped course · replot or hold away from rock"
func _move(u: Dictionary,dt: float,speed: float,holding: bool,report_collision: bool=true,player_craft: bool=false) -> void:
	if not flow_enabled:
		super._move(u,dt,speed,holding,report_collision,player_craft);return
	var flow=water_at(u.pos)
	if flow==Vector2.ZERO and not u.has("flow_station"):
		super._move(u,dt,speed,holding,report_collision,player_craft);return
	if holding and not u.has("flow_station"):u.flow_station=u.pos
	if not holding and not u.route.is_empty():u.erase("flow_station")
	var desired=flow if u.route.is_empty() and not u.has("flow_station") else Vector2.ZERO
	if player_craft: speed=RouteProgram.speed(u,speed,u.name=="QUIETUS")
	if not u.route.is_empty() and not holding:
		var dest=u.route[0]
		var delta:Vector2=dest.pos-u.pos
		var arrival=9.0 if dest.stop else 11.0
		var mode_boundary=player_craft and dest.get("goal",false) and u.route.size()>1 and u.route[1].get("mode","inherit")!="inherit" and u.route[1].get("mode","inherit")!=dest.get("mode","inherit")
		if not mode_boundary and not dest.stop and u.route.size()>1 and delta.length()<28 and segment_safe(u.pos,u.route[1].pos,24): arrival=28.0
		if delta.length()<arrival:
			if dest.stop and ground_velocity(u).length()>2:
				_push(u,dt,(dest.pos-u.pos).limit_length(4.0),flow,speed,report_collision,player_craft)
				return
			if dest.stop and u.route.size()==1:u.flow_station=dest.pos
			u.route.pop_front()
			if player_craft: RouteProgram.arrived(u,dest); speed=RouteProgram.speed(u,speed,u.name=="QUIETUS")
			if dest.stop: u.vel=u.vel.move_toward(Vector2.ZERO,120*dt)
		if not u.route.is_empty():
			delta=u.route[0].pos-u.pos
			var target_speed=speed
			if u.route[0].stop: target_speed=minf(speed,sqrt(maxf(0,delta.length()-4)*70))
			var target_angle=delta.angle()
			var turn=absf(angle_difference(u.angle,target_angle))
			if turn>0.3: target_speed=minf(target_speed,28.0+35.0*maxf(0,cos(turn)))
			if player_craft and turn>0.3:
				# Reserve hull room for the remaining turn and current momentum.
				# Withhold thrust, retaining normal braking/rotation until the arc fits.
				var maneuver_room=12.0+target_speed*turn/1.8+ground_velocity(u).length_squared()/84.0
				if blocked(u.pos,maneuver_room): target_speed=0.0
			if turn>0.15 and blocked(u.pos,24): target_speed=0.0 # Thruster-turn away before a near-wall restart.
			if u.route.size()>1:
				var next_direction:Vector2=u.route[1].pos-u.route[0].pos
				var corner=absf(delta.angle_to(next_direction))
				if corner>0.3: target_speed=minf(target_speed,20+sqrt(delta.length()*35))
			desired=delta.normalized()*target_speed
	if (holding or u.route.is_empty()) and u.has("flow_station"):
		desired=((u.flow_station-u.pos)*2.0).limit_length(12.0)
	_push(u,dt,desired,flow,speed,report_collision,player_craft)
