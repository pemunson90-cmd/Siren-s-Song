import subprocess,pathlib,re,json,difflib
root=pathlib.Path.cwd();base='bbc1bed0e6874cb722334309162d1b858f5a299b'
def git(*args):return subprocess.check_output(['git',*args])
changed=git('diff','--name-only',base,'HEAD').decode().splitlines()
report={'head':git('rev-parse','HEAD').decode().strip(),'base':base,'files':changed}
report['comment_only']={}
for p in changed:
 if p.endswith('.gd'):
  a=git('show',base+':'+p);b=git('show','HEAD:'+p)
  def executable(data):return [x.rstrip(b'\r') for x in data.split(b'\n') if x.strip() and not x.lstrip().startswith(b'#')]
  assert executable(a)==executable(b),p+' EXECUTABLE DIFFERENCE'
  report['comment_only'][p]=True
  if '/diagnostics/' in p:
   aa=a.splitlines(keepends=True);bb=b.splitlines(keepends=True)
   sm=difflib.SequenceMatcher(a=[x.rstrip(b'\r\n') for x in aa],b=[x.rstrip(b'\r\n') for x in bb],autojunk=False)
   for tag,i,j,k,l in sm.get_opcodes():
    if tag=='equal':assert aa[i:j]==bb[k:l],p+' UNCHANGED LINE BYTES DIFFER'
report['gd_count']=len(report['comment_only'])
old=git('show',base+':docs/RESUME.md');history=git('show','HEAD:docs/RESUME_2026-10-24_HISTORY.md')
assert history.endswith(old),'History does not preserve original bytes'
report['history_original_bytes_preserved']=len(old)
for p,limit in [('docs/MODULES.md',120),('docs/CONTINUATION.md',40),('docs/WORKBENCH.md',40)]:
 n=len((root/p).read_text(encoding='utf-8').splitlines());assert n<limit;report[p+'_lines']=n
modules=(root/'docs/MODULES.md').read_text(encoding='utf-8');rows=[line for line in modules.splitlines() if line.startswith('| ')][2:]
report['module_groups']=len(rows)
files=list((root/'game/src').rglob('*'));missing=[];refs=[]
for token in re.findall(r'`([^`]+)`',modules):
 for name in re.findall(r'[\w/]+\.gd',token):
  if '/' in name:
   exists=(root/'game/src'/name).is_file()
  else:exists=any(p.name.lower()==name.lower() for p in files)
  if not exists:missing.append(name)
  refs.append(name)
report['source_path_refs']=len(refs);report['missing_source_paths']=missing
assert not missing,missing
registered={x.split('|')[0] for x in (root/'game/tests/suites.txt').read_text(encoding='utf-8').splitlines() if x and not x.startswith('#')}
tests=set(re.findall(r'`([\w]+(?:_tests|_probe|_measurements))`',modules));tests.add('run_tests')
report['named_test_refs']=len(tests);report['unregistered_tests']=sorted(tests-registered)
assert not tests-registered,tests-registered
broken=[];checked=[]
for p in changed:
 if not p.endswith('.md'):continue
 text=(root/p).read_text(encoding='utf-8')
 for url in re.findall(r'\[[^\]]*\]\(([^)]+)\)',text):
  if '://' in url or url.startswith('#'):continue
  path=url.split('#')[0].split(' ')[0]
  if not path:continue
  dest=root/p;dest=dest.parent/path
  checked.append([p,path])
  if not dest.exists():broken.append([p,path])
report['local_link_count']=len(checked);report['broken_local_links']=broken
print(json.dumps(report,indent=2))