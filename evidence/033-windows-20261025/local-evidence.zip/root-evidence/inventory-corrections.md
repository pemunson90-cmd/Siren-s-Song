# Mechanical inventory qualifications

The initial small-worker inventory had search misses, not demonstrated game defects: the old sonar_sweeper source was intentionally superseded by PR70 sweeper_senses;049 extends the existing first_siren_cue module; registered a11y_cues_tests inherits the SceneTree test body in src/presentation/accessibility/cue_tests.gd; onboard2 and final-pair/photo-ending suites are registered. Root verified their actual paths and registry rows before writing MODULES. The worker inventory remains advisory evidence, not proof of the table by itself.

Root also corrected the proposed lock-warning revert: frames() is shared with Soundscape and accessibility, so removing only the visual overlay must retain that helper. Photo-audio cue tables are shared; profile four-file legacy copying does not migrate SAVE2 sidecars. Those dependency limits are documented in current headers and MODULES. Eight GDScript changes are header comments only; executable lines match bbc1bed0.

The Windows date-wording helper initially failed on a default-codepage read and was corrected to explicit UTF-8. Import/core then separately passed. Legacy AI trace CRLF body lines were preserved rather than normalized; new comment lines use LF to pass whitespace checks. These were tooling/setup corrections, not gameplay test failures.
