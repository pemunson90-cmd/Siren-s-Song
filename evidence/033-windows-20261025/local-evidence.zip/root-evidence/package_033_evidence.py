from __future__ import annotations
import hashlib
import json
import os
import zlib
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

base = Path(__file__).resolve().parent.parent
source_root = base / '033-evidence'
review_root = source_root / 'reviewer-e0'
out_dir = base / '033-archive' / 'evidence' / '033-windows-20261025'
out_dir.mkdir(parents=True, exist_ok=True)
archive = out_dir / 'local-evidence.zip'
manifest_path = out_dir / 'manifest.json'
progress_path = out_dir / 'PROGRESS.md'
root_exts = {'.log', '.json', '.md', '.py'}
review_exts = {'.log', '.json', '.py', '.ps1'}

sources = []
for p in sorted(source_root.iterdir()):
    if p.is_file() and p.suffix.lower() in root_exts and not p.name.lower().endswith('.tmp'):
        sources.append(('root-evidence/' + p.name, p))
for p in sorted(review_root.iterdir()):
    if p.is_file() and p.suffix.lower() in review_exts and not p.name.lower().endswith('.tmp'):
        sources.append(('reviewer-e0/' + p.name, p))

members = []
with ZipFile(archive, 'w', compression=ZIP_DEFLATED, compresslevel=9) as zf:
    for arcname, src in sources:
        data = src.read_bytes()
        zf.writestr(arcname, data)
        members.append({
            'archive_member': arcname,
            'source_absolute': str(src.resolve()),
            'source_relative': str(src.relative_to(base)),
            'size': len(data),
            'sha256': hashlib.sha256(data).hexdigest(),
            'crc32': f'{zlib.crc32(data) & 0xffffffff:08x}',
        })

with ZipFile(archive, 'r') as zf:
    bad = zf.testzip()
    if bad is not None:
        raise RuntimeError(f'ZIP CRC failure at {bad}')
    names = set(zf.namelist())
    if names != {m['archive_member'] for m in members}:
        raise RuntimeError('ZIP member list differs from manifest source list')
    for m in members:
        archived = zf.read(m['archive_member'])
        source = Path(m['source_absolute']).read_bytes()
        if archived != source:
            raise RuntimeError(f'Archived bytes differ from source: {m["source_relative"]}')
        if hashlib.sha256(archived).hexdigest() != m['sha256']:
            raise RuntimeError(f'Archived SHA mismatch: {m["archive_member"]}')

manifest = {
    'task': '033 Windows evidence package',
    'review': {
        'head': 'e0c6e8f6e80059e93601e21998d62c85e3a72f70',
        'base': 'bbc1bed0',
        'pull_request': 145,
        'independent_status': 'PASS',
        'independent_run': '6404465570',
    },
    'archive': {
        'path': str(archive.resolve()),
        'size': archive.stat().st_size,
        'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
        'member_count': len(members),
        'testzip': 'passed',
        'source_byte_comparison': 'passed for every member',
    },
    'members': members,
    'omissions': [
        'Temporary files excluded.',
        'Reviewer isolated user-data directories excluded; only direct reviewer-e0 files with requested extensions were included.',
        'No hosted final game result is claimed: run 40241428577 game job was still pending at package time.',
        'No complete revert-combination, human, physical-phone, or full campaign proof is claimed.',
    ],
}
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
progress = '''# 033 evidence package progress

- Source head: e0c6e8f6e80059e93601e21998d62c85e3a72f70; base: bbc1bed0; PR 145 independent review PASS, run 6404465570.
- Local import/core checks: 836 checks, 0 failures, reported by root and a non-author reviewer.
- Guidance: 10 tests; source review: 44 groups and 54 lines; 8 comment-only GDScript files.
- The existing 17,516-byte RESUME was preserved. The small module inventory draft is advisory; root corrections are retained in inventory-corrections.md.
- Hosted run 40241428577 had guidance green while the game job was still pending. This package does not claim hosted game completion or merge.
- This is diagnostic evidence, not proof of every revert combination, a complete campaign, human usability, or physical-phone behavior.
- Archive verification: ZIP testzip passed and every member was byte-compared with its source. See manifest.json for member hashes, CRCs and sizes.
'''
progress_path.write_text(progress, encoding='utf-8')
print(json.dumps({
    'archive': str(archive.resolve()),
    'manifest': str(manifest_path.resolve()),
    'progress': str(progress_path.resolve()),
    'member_count': len(members),
    'archive_size': archive.stat().st_size,
    'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
}, indent=2))
