import pathlib,json,re,hashlib,subprocess
root=pathlib.Path(r'C:/Users/Archi/Documents/Codex/2026-10-24/you-are-codex-the-implementation-worker/050-evidence/independent-b7addc')
results=json.loads((root/'results.json').read_text(encoding='utf-8-sig'))
assert len(results)==29, len(results)
for row in results:
    assert row['exit']==0 and row['pass'] and not row['errors'] and not row['failLines'],row['suite']
    raw=pathlib.Path(row['log']).read_text(encoding='utf-8-sig')
    assert not re.search(r'SCRIPT ERROR:|(^|\s)ERROR:|resources still in use|ObjectDB instances leaked|^FAIL ',raw,re.M),row['suite']
    if row['suite']!='import': assert row['failures']==0 and row['checks']>0,row['suite']
on=[line for line in (root/'opening_depth_journeys.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('OPENING ') and 'outcome=' in line]
off=[line for line in (root/'opening_flag_off.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('OPENING ') and 'outcome=' in line]
assert len(on)==5 and on==off,(on,off)
comparison={'rows':on,'exact_printed_metrics_match':True,'split_survivors':'Split source explicitly asserts all craft alive; its print omits alive. The other four rows print alive=[true,true,true]. Both runs pass all49 assertions.'}
(root/'opening-comparison.json').write_text(json.dumps(comparison,indent=2),encoding='utf-8')
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='b7addca49c997772d8704afbda33ff6485d42b40',head
source_diff=subprocess.run(['git','diff','--quiet','HEAD','--','game/src','game/tests','docs','scripts']).returncode
assert source_diff==0,source_diff
manifest=[]
for p in sorted(root.glob('*.log')):manifest.append({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(root/'logs-manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
summary={'head':head,'processes':len(results),'checks':sum(r['checks'] or 0 for r in results),'failures':sum(r['failures'] or 0 for r in results),'seconds':round(sum(r['seconds'] for r in results),3),'all_exit_zero':True,'strict_errors':0,'source_diff_exit':source_diff,'opening_exact_match':True,'photo_rows':sum(r['suite'].startswith('photo_row_') for r in results),'photo_checks':sum(r['checks'] or 0 for r in results if r['suite'].startswith('photo_row_'))}
(root/'verified-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
print('\n'.join(on))
