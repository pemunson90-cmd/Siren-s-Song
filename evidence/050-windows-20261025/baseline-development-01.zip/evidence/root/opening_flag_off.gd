extends "res://tests/opening_depth_journeys.gd"
const HUNT_TABLE=preload("res://src/simulation/hunt_pressure/hunt_table.gd")
func _initialize():
 HUNT_TABLE.enabled=false
 super._initialize()
