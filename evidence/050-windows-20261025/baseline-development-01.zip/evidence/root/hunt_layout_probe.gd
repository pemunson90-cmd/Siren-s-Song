extends "res://tests/status_text_ui_tests.gd"
func dump(game,phase):
 var hud=game.mission_hud
 var rows=[]
 for b in hud.action_controls().values():
  if b.is_visible_in_tree():rows.append([b.get_meta("action",""),b.get_global_rect()])
 var readouts=[]
 if hud.fleet.is_visible_in_tree():
  for r in hud.fleet.readouts:readouts.append(Rect2(hud.fleet.global_position+r.rect.position,r.rect.size))
 print("HUNT_GEOM ",phase," viewport=",root.get_visible_rect().size," window=",root.size," safe=",game.get_global_rect()," hud=",hud.get_global_rect()," touch=",hud.touch_height," text_scale=",hud.text_scale," alarm=",hud.alarm.get_global_rect() if hud.alarm.visible else "hidden"," intent=",hud.intent.get_global_rect() if hud.intent.visible else "hidden"," readouts=",readouts," controls=",rows)
func run():
 for shape in [Vector2i(2520,1080),Vector2i(2184,1968),Vector2i(960,432)]:
  var game=await make_game(6,shape)
  dump(game,"basic "+str(shape))
  await tap(game.advanced_button.get_global_rect().get_center())
  dump(game,"fleet "+str(shape))
  game.queue_free();await settle()
 print("HUNT GEOM CHECKS 1 FAILURES 0")
 quit(0)
