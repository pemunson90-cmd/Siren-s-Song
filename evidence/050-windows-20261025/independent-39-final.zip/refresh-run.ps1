$ErrorActionPreference='Stop'
$repo='C:/Users/Archi/Documents/Codex/2026-10-24/you-are-codex-the-implementation-worker/050-hunt-restore'
$ev='C:/Users/Archi/Documents/Codex/2026-10-24/you-are-codex-the-implementation-worker/050-evidence/independent-39d855'
Set-Location $repo
. ($repo+'/scripts/toolchain/win/common.ps1')
$logged=(Get-Command Invoke-GodotLogged).Definition.Replace('-NoNewWindow','-WindowStyle Hidden');Set-Item Function:Invoke-GodotLogged ([scriptblock]::Create($logged))
$head=git rev-parse HEAD
if($head -ne '39d855151534dc81a277e34367341c8711e320cf'){throw 'HEAD changed'}
$args=@('--path',($repo+'/game'),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--script',($ev+'/refresh_probe.gd'))
$log=$ev+'/refresh-native.log';$data=$ev+'/refresh-data-'+[guid]::NewGuid().ToString('N');$watch=[Diagnostics.Stopwatch]::StartNew()
$exit=Invoke-GodotLogged -GodotArgs $args -Log $log -TimeoutSec 120 -IsolatedRoot $data
$watch.Stop();$parsed=Test-GodotLog -Log $log -Prefix 'INDEPENDENT HUNT REFRESH' -RequireSummary $true
$result=[pscustomobject]@{suite='external_refresh_native';head=$head;exit=$exit;seconds=$watch.Elapsed.TotalSeconds;checks=$parsed.Checks;failures=$parsed.Failures;errors=$parsed.Problems;log=$log;userdata=$data;command=((Assert-GodotExe)+' '+(ConvertTo-ArgString $args))}
$result|ConvertTo-Json -Depth 6|Set-Content ($ev+'/refresh-results.json') -Encoding UTF8
$result|ConvertTo-Json -Compress
if($exit -ne 0 -or $parsed.Problems.Count -gt 0){throw 'REFRESH_PROBE_FAILED'}
