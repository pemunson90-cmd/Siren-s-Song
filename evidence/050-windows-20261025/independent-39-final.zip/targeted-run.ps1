$ErrorActionPreference='Stop'
$repo='C:/Users/Archi/Documents/Codex/2026-10-24/you-are-codex-the-implementation-worker/050-hunt-restore'
$ev='C:/Users/Archi/Documents/Codex/2026-10-24/you-are-codex-the-implementation-worker/050-evidence/independent-39d855'
Set-Location $repo
. ($repo+'/scripts/toolchain/win/common.ps1')
$logged=(Get-Command Invoke-GodotLogged).Definition.Replace('-NoNewWindow','-WindowStyle Hidden')
Set-Item Function:Invoke-GodotLogged ([scriptblock]::Create($logged))
$exe=Assert-GodotExe
Get-FileHash -LiteralPath $exe -Algorithm SHA512|ConvertTo-Json|Set-Content ($ev+'/binary.json')
$rows=Read-SuiteRegistry
$expected='39d855151534dc81a277e34367341c8711e320cf'
$head=git rev-parse HEAD
if($head -ne $expected){throw 'Wrong frozen head'}
$head|Set-Content ($ev+'/targeted-head-before.log')
git status --short|Set-Content ($ev+'/targeted-status-before.log')
$root=$ev+'/data-'+[guid]::NewGuid().ToString('N')
$suites=@('radial_hud_tests','playfield_hud_tests','fleet_instruments_ui_tests','expedition_instruments_ui_tests','campaign_instruments_ui_tests','lock_warning_ui_tests','map_gesture_tests')
$results=@()
foreach($name in $suites){
 if((git rev-parse HEAD) -ne $expected){throw 'Frozen HEAD changed'}
 $native=$name -eq 'hunt_meter_ui_native'
 $suite=if($native){'hunt_meter_ui_tests'}elseif($name -eq 'opening_flag_off'){'opening_depth_journeys'}else{$name}
 $args=@('--path',($repo+'/game'),'--audio-driver','Dummy')
 if($native){$args+=@('--rendering-method','gl_compatibility')}else{$args+=@('--headless')}
 if($suite -eq 'import'){$args+=@('--editor','--import')}elseif($name -eq 'opening_flag_off'){$args+=@('--script',($repo+'/../050-evidence/opening_flag_off.gd'))}else{$args+=@('--script',('res://tests/'+$suite+'.gd'))}
 if($native){$args+=@('--',('--capture-dir='+$ev+'/captures'))}
 $log=$ev+'/'+$name+'.log';$isolation=$root+'/'+$name
 Write-Output ('START '+$name)
 $watch=[Diagnostics.Stopwatch]::StartNew()
 $exit=Invoke-GodotLogged -GodotArgs $args -Log $log -TimeoutSec 300 -IsolatedRoot $isolation
 $watch.Stop()
 $prefix=if($suite -eq 'import'){''}else{($rows|Where-Object {$_.Name -eq $suite}).Prefix}
 $parsed=Test-GodotLog -Log $log -Prefix $prefix -RequireSummary ($suite -ne 'import')
 $failLines=@(Get-Content $log|Where-Object {$_ -match '^FAIL '})
 $ok=$exit -eq 0 -and $parsed.Problems.Count -eq 0 -and $failLines.Count -eq 0
 $result=[pscustomobject]@{suite=$name;head=$expected;exit=$exit;pass=$ok;seconds=[math]::Round($watch.Elapsed.TotalSeconds,3);summary=$parsed.Summary;checks=$parsed.Checks;failures=$parsed.Failures;errors=$parsed.Problems;failLines=$failLines;log=$log;userdata=$isolation;command=($exe+' '+(ConvertTo-ArgString $args))}
 $results+=$result
 $results|ConvertTo-Json -Depth 6|Set-Content ($ev+'/targeted-results.json') -Encoding UTF8
 Write-Output ($result|ConvertTo-Json -Compress -Depth 5)
 if(-not $ok){throw ('CHECK_FAILED '+$name)}
}
git rev-parse HEAD|Set-Content ($ev+'/targeted-head-after.log')


