import pathlib,subprocess,re,json
base='0fb3873e4c0650560d57d19c89b106ae3803747c'
head='39d855151534dc81a277e34367341c8711e320cf'
out=pathlib.Path(r'C:/Users/Archi/Documents/Codex/2026-10-24/you-are-codex-the-implementation-worker/050-evidence/independent-39d855')
def text(path,revision=None):
    raw=subprocess.check_output(['git','show',revision+':'+path]) if revision else pathlib.Path(path).read_bytes()
    return raw.decode('utf-8').replace('\r\n','\n')
def fn(s,name):
    m=re.search(r'^(?:static )?func '+re.escape(name)+r'\(',s,re.M)
    assert m,name
    n=re.search(r'^(?:static )?func ',s[m.end():],re.M)
    return s[m.start():m.end()+n.start() if n else len(s)]
p='game/src/simulation/simulation.gd';old=text(p,base);new=text(p)
checks={name:fn(old,name)==fn(new,name) for name in ['_heard_arrival','_move','_hull_contacts','_advance_projectiles','_visual_pursuit']}
a=fn(new,'_threats').replace('HuntPressure.sight(mission,s,Recon.readiness(s))','Recon.readiness(s)')
checks['threats_except_two_sight_factors']=a==fn(old,'_threats')
p='game/src/simulation/recon_consequences.gd';checks['shared_readiness']=fn(text(p,base),'readiness')==fn(text(p),'readiness')
p='game/src/audio/soundscape.gd';checks['lock_audio']=fn(text(p,base),'_lock_update')==fn(text(p),'_lock_update')
p='docs/design/HUNT_RESTORE.md';checks['historical_design_retained']=text(p).split('## Historical 24 October proposal (retained in full)\n\n',1)[1]==text(p,base).split('\n\n',1)[1]
changed=subprocess.check_output(['git','diff','--name-only',base,head],text=True).splitlines()
checks['existing_tests_unchanged']=all(p in ['game/tests/hunt_pressure_tests.gd','game/tests/hunt_pressure_integration_tests.gd','game/tests/hunt_meter_ui_tests.gd','game/tests/suites.txt'] for p in changed if p.startswith('game/tests/'))
checks['head_exact']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
result={'base':base,'head':head,'checks':checks,'all_pass':all(checks.values()),'note':'Independent explicit UTF8 read, CRLF normalized; no source writes.'}
(out/'protected-source-proof.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
raise SystemExit(0 if result['all_pass'] else 1)

