extends "res://tests/density_main.gd"
var review_refreshes=0
func _refresh()->void:
 review_refreshes+=1
 super._refresh()
