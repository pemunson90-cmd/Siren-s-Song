import pathlib,json,re,hashlib,struct,subprocess
root=pathlib.Path(r'C:/Users/Archi/Documents/Codex/2026-10-24/you-are-codex-the-implementation-worker/050-evidence/independent-39d855')
main=json.loads((root/'results.json').read_text(encoding='utf-8-sig'))
extra=json.loads((root/'targeted-results.json').read_text(encoding='utf-8-sig'))
probe=json.loads((root/'refresh-results.json').read_text(encoding='utf-8-sig'))
assert len(main)==30 and len(extra)==7
rows=main+extra+[probe]
for r in rows:
 assert r['head']=='39d855151534dc81a277e34367341c8711e320cf'
 assert r['exit']==0 and r.get('failures',0) in (0,None) and not r['errors'],r
 raw=pathlib.Path(r['log']).read_text(encoding='utf-8-sig')
 assert not re.search(r'SCRIPT ERROR:|(^|\s)ERROR:|resources still in use|ObjectDB instances leaked|^FAIL ',raw,re.M),r['suite']
 if r['suite']!='import':
  summary=re.findall(r'CHECKS (\d+) FAILURES (\d+)',raw)
  assert summary and int(summary[-1][0])==r['checks'] and int(summary[-1][1])==0,(r['suite'],summary)
captures=[]
for p in sorted((root/'captures').glob('*.png')):
 data=p.read_bytes(); assert data[:8]==b'\x89PNG\r\n\x1a\n'
 w,h=struct.unpack('>II',data[16:24])
 captures.append(dict(path=str(p),width=w,height=h,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
assert len(captures)==21
(root/'captures-manifest.json').write_text(json.dumps(captures,indent=2),encoding='utf-8')
(root/'all-results.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
summary=dict(head=rows[0]['head'],base='0fb3873e4c0650560d57d19c89b106ae3803747c',requested_processes=37,requested_checks=sum(r['checks'] or 0 for r in main+extra),external_processes=1,external_checks=152,all_checks=sum(r['checks'] or 0 for r in rows),failures=0,strict_errors=0,all_exit_zero=True,main_seconds=round(sum(r['seconds'] for r in main),3),targeted_seconds=round(sum(r['seconds'] for r in extra),3),external_seconds=probe['seconds'],captures=len(captures))
(root/'complete-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
manifest=[dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(root.glob('*.log'))]
(root/'logs-manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
print('\n'.join(f"{r['suite']}: {r['checks']} checks, exit {r['exit']}, {r['seconds']}s" for r in rows))
