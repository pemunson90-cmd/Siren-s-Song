extends SceneTree
func _initialize():
 var h=load("res://tests/photo_row_journey_support.gd").new(7,"tender_door")
 print("SUPPORT SMOKE CHECKS %d FAILURES %d"%[h.checks,h.failures])
 quit(1 if h.failures else 0)
