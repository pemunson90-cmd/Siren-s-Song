extends SceneTree
const Sim=preload("res://src/simulation/simulation.gd")
const Photo=preload("res://src/simulation/photo_capture.gd")
func run(s,seconds):
 s.paused=false
 for n in roundi(seconds*60):s.advance(1.0/60.0)
 s.paused=true
func _initialize():
 print("ALL CASES GEOMETRY-ONLY DIAGNOSTICS, NOT JOURNEY PROOF. LIVE SIRENS UNMODIFIED.")
 var s=Sim.new();s.start(7)
 s.units[0].pos=Vector2(695,610);s.units[0].angle=PI
 run(s,0.2);s.command("frame",{"mode":"tight","focus":"tender_door"});s.command("camera");run(s,4.2)
 print("TENDER_SECOND_CONTEXT ",s.camera_context()," command=",s.command("camera"));run(s,4.2)
 var obj=s.mission.objectives.filter(func(o):return o.get("optical","")=="tender_door")[0]
 var shots=Photo.shots_for(s.mission,"tender_door")
 print("TENDER_RESULT captured=",obj.captured," elapsed=",s.elapsed," hull=",s.hull," shots=",shots.map(func(a):return {"obj":a.obj,"key":a.key,"usable":a.usable,"features":a.features,"intel":a.intel,"q":a.q,"time":a.time})," message=",s.message)
 for distance in [90.0,150.0,210.0]:
  for delta in [-0.9,-0.6,0.0,0.6,0.9]:
   s=Sim.new();s.start(8)
   var o=s.mission.objectives.filter(func(a):return a.get("optical","")=="relay_blink")[0]
   var point=o.pos+Vector2.from_angle(PI+delta)*distance
   if not s.Depth.clear(s,point,point,1,24.0) or not s.Depth.clear(s,point,o.pos,1):continue
   s.units[0].pos=point;s.units[0].angle=point.angle_to_point(o.pos)
   run(s,0.2);s.command("frame",{"mode":"tight","focus":"relay_blink"})
   var ctx=s.camera_context();var cmd=s.command("camera");run(s,10.0)
   var ten={"time":s.elapsed,"captured":o.captured,"progress":s.captures[0].duplicate(true),"shots":Photo.shots_for(s.mission,"relay_blink").size()}
   run(s,18.3)
   shots=Photo.shots_for(s.mission,"relay_blink")
   print("RELAY ",JSON.stringify({"point":str(point),"distance":distance,"delta":delta,"context":ctx,"command":cmd,"at10":ten,"elapsed":s.elapsed,"hull":s.hull,"outcome":s.outcome,"captured":o.captured,"shots":shots.map(func(a):return {"obj":a.obj,"key":a.key,"usable":a.usable,"features":a.features,"intel":a.intel,"q":a.q,"time":a.time}),"message":s.message}))
 quit()