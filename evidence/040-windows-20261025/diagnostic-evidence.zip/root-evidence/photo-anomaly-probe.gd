extends SceneTree
const Sim=preload("res://src/simulation/simulation.gd")
const Photo=preload("res://src/simulation/photo_capture.gd")
func run(s,seconds:float):
 s.paused=false
 for n in roundi(seconds*60):s.advance(1.0/60.0)
 s.paused=true
func report(s,h,o,label):
 var shots=[]
 for shot in Photo.shots_for(s.mission,o.optical):
  shots.append({"key":shot.key,"obj":shot.obj,"usable":shot.usable,"intel":shot.intel,"features":shot.features,"q":shot.q,"time":shot.time})
 print(label," ",JSON.stringify({"elapsed":s.elapsed,"descriptor_found":h.get("found","N/A"),"descriptor_has_captured":h.has("captured"),"descriptor_captured_defaultfalse":h.get("captured",false),"objective_index":s.mission.objectives.find(o),"captured":o.captured,"shots":shots,"capture":s.captures[0],"message":s.message,"hull":s.hull,"outcome":s.outcome,"sirens":s.sirens.map(func(e):return {"pos":str(e.pos),"mode":e.mode}),"unitpos":str(s.units[0].pos)}))
func _initialize():
 for fixture in [[7,"tender_door",0.0],[8,"relay_blink",0.0],[8,"relay_blink",7.0]]:
  var s=Sim.new();s.start(fixture[0]);run(s,fixture[2])
  var key=fixture[1]
  var h=s.mission.objectives.filter(func(o):return o.get("optical","")==key)[0] if fixture[0]==8 else s.mission.photo_hidden.filter(func(o):return o.key==key)[0]
  var point=h.pos+Vector2.from_angle(h.subject.facing)*45.0
  print("GEOMETRY_ONLY_DIAGNOSTIC_NOT_JOURNEY key=",key," start=",s.elapsed," point=",point," clear=",s.Depth.clear(s,point,point,1,24.0)," sightclear=",s.Depth.clear(s,point,h.pos,1)," sirens=",s.sirens.size())
  s.units[0].pos=point;s.units[0].band=1;s.units[0].angle=point.angle_to_point(h.pos);s.units[0].vel=Vector2.ZERO
  run(s,0.2)
  var found=s.mission.objectives.filter(func(o):return o.get("optical","")==key)
  if found.is_empty():print("NO_DISCOVERY");continue
  var o=found[0]
  print("FRAME ",s.command("frame",{"mode":"tight","focus":key})," CONTEXT ",s.camera_context()," CAMERA ",s.command("camera"))
  run(s,10.0);report(s,h,o,"AT10")
  if fixture[0]==8:run(s,18.3);report(s,h,o,"AT28_3")
 quit()