extends SceneTree
const Sim=preload("res://src/simulation/simulation.gd")
const TARGETS={7:Vector2(800,610),8:Vector2(1190,1680),11:Vector2(3000,2810),14:Vector2(1530,1000),18:Vector2(1670,1220)}
func nearest_route(s,goal:Vector2,band:int)->void:
 var start:Vector2=s.units[0].pos
 var q=[];var seen={};var prev={};var points={}
 for x in range(50,4550,100):
  for y in range(50,4550,100):
   var p=Vector2(x,y)
   if start.distance_to(p)<150 and s.Depth.clear(s,start,p,band,24.0):
    var k=Vector2i(x,y);q.append(k);seen[k]=true;points[k]=p
 var dirs=[Vector2i(100,0),Vector2i(-100,0),Vector2i(0,100),Vector2i(0,-100),Vector2i(100,100),Vector2i(-100,100),Vector2i(100,-100),Vector2i(-100,-100)]
 var found=Vector2i(-1,-1);var best=INF;var nearest=Vector2i(-1,-1);var i=0
 while i<q.size():
  var k:Vector2i=q[i];i+=1;var p:Vector2=points[k]
  var d=p.distance_to(goal)
  if d<best:best=d;nearest=k
  if d<135 and s.Depth.clear(s,p,goal,band,24.0):found=k;break
  for off in dirs:
   var next=k+off;var point=Vector2(next.x,next.y)
   if next.x<50 or next.y<50 or next.x>4500 or next.y>4500 or seen.has(next):continue
   if not s.Depth.clear(s,p,point,band,24.0):continue
   seen[next]=true;prev[next]=k;points[next]=point;q.append(next)
 var path=[];var cur=found if found.x>=0 else nearest
 while cur.x>=0:
  path.push_front(points[cur]);cur=prev.get(cur,Vector2i(-1,-1))
 print("GRID op=",s.mission.get("index",-1)," band=",band," found=",found.x>=0," best=",best," nodes=",i," path=",path)
func _initialize():
 for op in TARGETS:
  var s=Sim.new();s.start(op,"endurance")
  for band in [1,2]:nearest_route(s,TARGETS[op],band)
 print("GRID CHECKS 1 FAILURES 0");quit(0)

