extends SceneTree
const Sim=preload("res://src/simulation/simulation.gd")
func _initialize():
 for op in [7,8,11,14,15,18,19]:
  var s=Sim.new();s.start(op,"endurance")
  var key={7:"tender_door",8:"relay_blink",11:"structure_edge",14:"buoy_blind",15:"vane_crack",18:"keel_mark",19:"boat_keel"}[op]
  var rows=s.mission.objectives.filter(func(o):return o.get("optical","")==key) if op==8 else s.mission.photo_hidden.filter(func(h):return h.key==key)
  var h=rows[0]
  print("PROBE ",op," spawn=",s.units.map(func(u):return [u.pos,u.band,u.alive])," subject=",h.pos," band=",h.subject.band," facing=",h.subject.facing," extraction=",s.mission.extraction," sirens=",s.sirens.map(func(e):return [e.pos,e.mode])," tools=",s.tools)
 print("PROBE CHECKS 1 FAILURES 0");quit(0)
