extends SceneTree
const J=preload("res://tests/photo_row_journey_support.gd")
const Sim=preload("res://src/simulation/simulation.gd")
const Photo=preload("res://src/simulation/photo_capture.gd")
const Catalog=preload("res://src/equipment/equipment_catalog.gd")
const Reward=preload("res://src/campaign/early_reward/early_reward.gd")
const Fleet=preload("res://src/campaign/fleet_inventory.gd")
func run(s,seconds:float)->void:
 s.paused=false
 for n in ceili(seconds/Sim.STEP):
  if not s.outcome.is_empty() or not s.units[0].alive:break
  s.advance(Sim.STEP)
 s.paused=true
func _initialize():
 var earned=Reward.earned(Reward.grant({},1,"won"),[])
 var fit=Catalog.choose(Catalog.default_loadout(),"quietus","quietus_tele_lens",earned)
 var launch=Fleet.launch(fit.fitted,earned,{},8,[0,1])
 print("TELE_LAUNCH ",fit.ok," / ",launch.ok," missing=",launch.missing)
 var h=J.new(8,"relay_blink",0,launch.launch)
 var ok=h.depth(2)
 for point in [Vector2(2050,650),Vector2(1950,750),Vector2(1750,850),Vector2(1750,1050),Vector2(1750,1150),Vector2(1550,1350),Vector2(1250,1650),Vector2(1190,1680),Vector2(1060,1680),Vector2(1130,1680)]:
  if ok:ok=h.go(point)
 if ok:ok=h.depth(1)
 if ok:ok=h.focus()
 if ok:ok=h.depth(2)
 print("ROUTE_BASE ok=",ok," t=",h.s.elapsed," pos=",h.s.units[0].pos," band=",h.s.units[0].band," target=",h.target()," hull=",h.s.hull," sirens=",h.s.sirens.size())
 if not ok:print("ROUTE_PROBE CHECKS 1 FAILURES 1");quit(1);return
 var start=h.s.snapshot()
 for wait in [0.0]:
  var s=Sim.new();var restored=s.restore(start);s.command("select",{"unit":0});run(s,wait)
  var rise=s.command("depth",{"band":1});run(s,4.2)
  var ctx=s.camera_context()
  var camera=s.command("camera") if s.outcome.is_empty() else false
  var e1=false;var e2=false
  s.paused=false
  for n in ceili(28.5/Sim.STEP):
   if n==420:e1=s.command("emp")
   if n==1050:e2=s.command("emp")
   if n==1710:print("ROUTE_EMP3 wait=",wait," accepted=",s.command("emp")," capture=",s.captures[0])
   if not s.outcome.is_empty() or not s.units[0].alive:break
   s.advance(Sim.STEP)
  s.paused=true
  var e3=false
  var shots=Photo.shots_for(s.mission,"relay_blink")
  var captured=s.mission.objectives[h.target()].get("captured",false)
  var usable=shots.any(func(a):return a.get("usable",false) and "relay_blink" in a.get("features",[]) and a.get("intel",{}).has("relay_blink"))
  var route=s.command("route",{"point":Vector2(900,1700)}) if s.outcome.is_empty() else false
  var dive=s.command("depth",{"band":2}) if s.outcome.is_empty() else false
  if dive:run(s,4.2)
  if route:run(s,26.0)
  print("ROUTE_COPY wait=",wait," restored=",restored," rise=",rise," target=",ctx.get("target",-1)," camera=",camera," emp=",e1,"/",e2,"/",e3," captured=",captured," usable=",usable," shots=",shots.size()," dive=",dive," route=",route," alive=",s.units[0].alive," hull=",s.hull," outcome=",s.outcome," t=",s.elapsed," pos=",s.units[0].pos," modes=",s.sirens.map(func(x):return x.mode))
 print("ROUTE_PROBE CHECKS 1 FAILURES 0");quit(0)



