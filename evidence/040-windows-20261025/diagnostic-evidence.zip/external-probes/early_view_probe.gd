extends SceneTree
const Sim=preload("res://src/simulation/simulation.gd")
const Photo=preload("res://src/simulation/photo_capture.gd")
func _initialize():
 for pair in [[14,"buoy_blind"],[18,"keel_mark"],[7,"tender_door"]]:
  var op:int=pair[0];var key:String=pair[1];var s=Sim.new();s.start(op,"endurance")
  var h=s.mission.photo_hidden.filter(func(row):return row.key==key)[0]
  var good=[]
  for dist in [65.0,90.0,120.0,150.0,165.0]:
   for delta in [-0.8,-0.6,-0.4,-0.2,0.0,0.2,0.4,0.6,0.8]:
    var point:Vector2=h.pos+Vector2.from_angle(h.subject.facing+delta)*dist
    if not s.Depth.clear(s,point,point,h.subject.band,24.0) or not s.Depth.clear(s,point,h.pos,h.subject.band):continue
    s.units[0].pos=point;s.units[0].band=h.subject.band;s.units[0].angle=point.angle_to_point(h.pos)
    Photo.set_frame(s,0,{"mode":"tight","focus":key})
    var f=Photo.frame(s,0,h)
    var rows=f.rows.filter(func(row):return row.id==key)
    if not rows.is_empty() and rows[0].ready and rows[0].q>=0.3:good.append([point,dist,delta,rows[0].q])
  print("VIEW ",op," ",key," good=",good)
 print("VIEW CHECKS 1 FAILURES 0");quit(0)
