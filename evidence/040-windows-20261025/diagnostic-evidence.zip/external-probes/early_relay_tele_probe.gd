extends SceneTree
const Sim=preload("res://src/simulation/simulation.gd")
const Catalog=preload("res://src/equipment/equipment_catalog.gd")
const Reward=preload("res://src/campaign/early_reward/early_reward.gd")
const Fleet=preload("res://src/campaign/fleet_inventory.gd")
const Photo=preload("res://src/simulation/photo_capture.gd")
func _initialize():
 var grant=Reward.grant({},1,"won")
 var earned=Reward.earned(grant,[])
 var choice=Catalog.choose(Catalog.default_loadout(),"quietus","quietus_tele_lens",earned)
 var public_launch=Fleet.launch(choice.fitted,earned,{},8,[0,1])
 print("TELE_PUBLIC grant=",grant," earned=",earned," choice_ok=",choice.ok," launch_ok=",public_launch.ok," missing=",public_launch.missing," fit=",public_launch.launch.get("fitted",{}))
 for d in [160.0,190.0,220.0,250.0,280.0,310.0]:
  var s=Sim.new();s.start(8,"endurance",public_launch.launch)
  var point=Vector2(1350.0-d,1680.0);var o=s.mission.objectives.filter(func(a):return a.get("optical","")=="relay_blink")[0]
  var clear=s.Depth.clear(s,point,point,1,24.0) and s.Depth.clear(s,point,o.pos,1)
  s.units[0].pos=Vector2(1190,1680);s.units[0].band=1;s.units[0].angle=0.0
  s.paused=false
  for warm in 60:s.advance(Sim.STEP)
  s.paused=true
  s.units[0].pos=point;s.units[0].angle=point.angle_to_point(o.pos)
  s.command("frame",{"mode":"tight","focus":"relay_blink"})
  var row=Photo.frame(s,0,o).rows.filter(func(a):return a.id=="relay_blink")[0]
  var ctx=s.camera_context()
  var camera=s.command("camera")
  s.paused=false
  for n in ceili(29.0/Sim.STEP):
   if n==420 or n==1050:print("TELE_EMP d=",d," n=",n," accepted=",s.command("emp")," capture=",s.captures[0]," tools=",s.tools)
   if not s.units[0].alive or not s.outcome.is_empty():break
   s.advance(Sim.STEP)
  var shots=Photo.shots_for(s.mission,"relay_blink")
  print("TELE_STAGE d=",d," point=",point," clear=",clear," preq=",row.q," ready=",row.ready," target=",ctx.get("target",-1)," camera=",camera," alive=",s.units[0].alive," elapsed=",s.elapsed," hull=",s.hull," shot_count=",shots.size()," usable=",shots.any(func(a):return a.get("usable",false))," captured=",o.captured," message=",s.message)
 print("TELE_PROBE CHECKS 1 FAILURES 0");quit(0)


