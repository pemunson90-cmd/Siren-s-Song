$ErrorActionPreference='Stop'
$repo='C:/Users/Archi/Documents/Codex/2026-10-24/you-are-codex-the-implementation-worker/040-photo-row-journeys'
$evidence='C:/Users/Archi/Documents/Codex/2026-10-24/you-are-codex-the-implementation-worker/040-evidence/reviewer44a'
$exe='C:/Users/Archi/.cache/sirens-song-toolchain/win/Godot_v4.6.3-stable_win64_console.exe'
$runRoot=$evidence+'/data-'+[guid]::NewGuid().ToString('N')
$suites=@('import','run_tests','photo_row_tender_door_journey_tests','photo_row_relay_blink_journey_tests','photo_row_structure_edge_journey_tests','photo_row_buoy_blind_journey_tests','photo_row_vane_crack_journey_tests','photo_row_keel_mark_journey_tests','photo_row_boat_keel_journey_tests','photo_row_locker_latch_journey_tests','photo_row_shutter_order_journey_tests','photo_row_bus_cable_journey_tests','photo_row_spindle_wear_journey_tests','photo_row_slide_mark_journey_tests','photo_row_bell_name_journey_tests','photo_row_feed_room_journey_tests','campaign_photo_rows_tests')
$results=@()
foreach($suite in $suites){
 $env:APPDATA=$runRoot+'/'+$suite+'/Roaming';$env:LOCALAPPDATA=$runRoot+'/'+$suite+'/Local'
 New-Item -ItemType Directory -Force -Path $env:APPDATA,$env:LOCALAPPDATA | Out-Null
 $log=$evidence+'/'+$suite+'.log';$err=$evidence+'/'+$suite+'.stderr.log'
 $args=@('--path',('"'+$repo+'/game"'),'--headless','--audio-driver','Dummy')
 if($suite -eq 'import'){$args+=@('--editor','--import')}else{$args+=@('--script',('res://tests/'+$suite+'.gd'))}
 Write-Output ('START '+$suite)
 $timer=[Diagnostics.Stopwatch]::StartNew()
 $p=Start-Process -FilePath $exe -ArgumentList $args -WindowStyle Hidden -PassThru -RedirectStandardOutput $log -RedirectStandardError $err
 $null=$p.Handle
 if(-not $p.WaitForExit(240000)){throw ('TIMEOUT '+$suite+' PID '+$p.Id)}
 $p.WaitForExit();$code=$p.ExitCode;$timer.Stop()
 $lines=@(Get-Content -LiteralPath $log)+@(Get-Content -LiteralPath $err)
 $issues=@($lines | Where-Object {$_ -match 'SCRIPT ERROR:|(^|\s)ERROR:|resources still in use|ObjectDB instances leaked|^FAIL '})
 $summaries=@($lines | Where-Object {$_ -match 'CHECKS \d+ FAILURES \d+'})
 $badSummary=@($summaries | Where-Object {$_ -notmatch 'FAILURES 0\s*$'})
 $ok=$code -eq 0 -and $issues.Count -eq 0 -and $badSummary.Count -eq 0 -and ($suite -eq 'import' -or $summaries.Count -gt 0)
 $item=[pscustomobject]@{suite=$suite;exit=$code;pass=$ok;seconds=[math]::Round($timer.Elapsed.TotalSeconds,3);summary=$summaries;errors=$issues;log=$log;stderr=$err;userdata=$env:APPDATA;command=($exe+' '+($args -join ' '))}
 $results+=$item
 $results | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath ($evidence+'/results.json') -Encoding UTF8
 Write-Output ($item | ConvertTo-Json -Compress -Depth 4)
 if(-not $ok){throw ('CHECK_FAILED '+$suite)}
}