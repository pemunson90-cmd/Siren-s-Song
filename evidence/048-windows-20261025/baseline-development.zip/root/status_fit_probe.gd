extends "res://tests/status_text_ui_tests.gd"
const View=preload("res://src/presentation/status_text/status_view.gd")
const Layout=preload("res://src/presentation/status_text/status_layout.gd")
func dump(hud,phase):
 var visible=View._area(hud)
 var body=Vector2.ZERO
 for b in hud.ring_buttons:body=Vector2(maxf(body.x,b.size.x),maxf(body.y,b.size.y))
 var top=hud.touch_height+Layout.HEADER_OFFSET
 var area=Rect2(Vector2(Layout.MARGIN,top),Vector2(visible.size.x-Layout.MARGIN*2,maxf(1,visible.size.y-top-Layout.MARGIN)))
 var ry=minf(hud.ring_radius,(area.size.y-body.y)/2)
 var rx=hud.ring_radius
 var lo=area.position+Vector2(rx,ry)+body/2
 var hi=area.end-Vector2(rx,ry)-body/2
 print("FIT_PROBE ",phase," anchor=",hud.anchor," center=",hud.center," global=",hud.global_position," size=",hud.size," viewport=",hud.get_viewport_rect()," visible=",visible," body=",body," area=",area," lo=",lo," hi=",hi," candidate=",hud.anchor.clamp(lo,hi)," axes=",hud.get_meta(View.AXES,Vector2.ZERO)," back=",hud.close_button.get_rect())
 for b in hud.ring_buttons:print("FIT_BUTTON ",phase," ",b.get_meta("action","")," ",b.get_global_rect())
func run():
 var game=await make_game(24,Vector2i(2520,1080))
 await tap(game.mission_hud.fleet.buttons[0].get_global_rect().get_center())
 var hud=game.mission_hud
 dump(hud,"before explicit fit")
 View.fit(hud)
 dump(hud,"after explicit fit")
 await settle()
 dump(hud,"after settle")
 game.queue_free();await settle()
 quit(0)
