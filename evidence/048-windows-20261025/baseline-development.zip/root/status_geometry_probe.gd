extends "res://tests/challenges_ui_tests.gd"
# Read-only radial geometry from actual touch at both recorded Fold7 shapes.
const Settings=preload("res://src/presentation/frontend/frontend_settings.gd")
const Store=preload("res://src/persistence/settings_store.gd")
func geometry(g,shape,stage):
 var hud=g.mission_hud
 var rows=[]
 for b in hud.ring_buttons:
  var r=b.get_global_rect()
  rows.append({"action":b.get_meta("action",""),"center":r.get_center(),"rect":r,"disabled":b.disabled})
 print("RADIAL_GEOMETRY shape=",shape," stage=",stage," viewport=",root.get_visible_rect().size," window=",root.size," host_bounds=",g.size," safe=",g.get_global_rect()," touch_h=",g.ui_touch_height," scale=",hud.text_scale," ring_center=",hud.center," ring_radius=",hud.ring_radius," buttons=",rows)
func run():
 for shape in [Vector2i(2520,1080),Vector2i(2184,1968)]:
  root.size=shape;await settle()
  var g=load("res://scenes/main.tscn").instantiate();g.set_script(load("res://tests/density_main.gd"));g.capture_scenario="status-geometry-probe"
  if shape.x==2520:g.fixture_safe_area=Rect2(136,0,2384,1080)
  root.add_child(g);await settle();g.set_process(false)
  var settings=Store.DEFAULTS.duplicate(true);settings.text_scale=1.5;Settings.apply(settings,g);await settle()
  g._start_mission(24);g._layout();await settle()
  await tap(g.mission_hud.fleet.buttons[0].get_global_rect().get_center());geometry(g,shape,"craft")
  await android_back();await tap(g.advanced_button.get_global_rect().get_center());geometry(g,shape,"fleet")
  g.queue_free();await settle()
 Settings.apply(Store.DEFAULTS)
 print("STATUS GEOMETRY PROBE CHECKS 1 FAILURES 0");quit(0)
