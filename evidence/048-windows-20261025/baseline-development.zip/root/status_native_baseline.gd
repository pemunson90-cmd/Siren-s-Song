extends "res://tests/challenges_ui_tests.gd"
# Read-only HUD baseline. Native touch plus mouse emulation; no game source edits.
const Settings=preload("res://src/presentation/frontend/frontend_settings.gd")
const Store=preload("res://src/persistence/settings_store.gd")
const IDS=[6,11,24,29]
var capture_dir=""
func picture(name:String):
 await RenderingServer.frame_post_draw
 var image=root.get_texture().get_image()
 var path=capture_dir.path_join(name+".png")
 var result=image.save_png(path)
 print("BASELINE_PNG name=",name," size=",image.get_size()," result=",result," path=",path)
func visible_text(game)->Dictionary:
 var hud=game.mission_hud
 return {"intent":hud.intent.text,"intent_visible":hud.intent.is_visible_in_tree(),"instrument":hud.instrument_info.text,"instrument_visible":hud.instrument_info.is_visible_in_tree(),"title":game.title_label.text,"detail":game.detail_label.text,"arrivals":hud.extra.arrivals.text,"arrivals_visible":hud.extra.arrivals.is_visible_in_tree(),"arrivals_disabled":hud.extra.arrivals.disabled,"context":game.sim.camera_context().get("text",""),"sim_message":game.sim.message}
func geometry(game,shape,id,stage):
 var metrics=game._ui_metrics()
 var clipped=[]
 for control in metrics.controls:
  if control.clipped:clipped.append(control.action)
 var dp=160.0/420.0*float(root.size.x)/root.get_visible_rect().size.x
 var arrivals=game.mission_hud.extra.arrivals
 var r=arrivals.get_global_rect()
 print("BASELINE_GEOMETRY id=",id," shape=",shape," stage=",stage," touch_height=",game.ui_touch_height," dp_scale=",dp," clipped=",clipped," arrivals_rect=",r," arrivals_dp=",r.size*dp," page=",game.mission_hud.page," screen=",game.screen)
func shape_case(shape:Vector2i):
 root.size=shape;await settle()
 for id in IDS:
  var game=load("res://scenes/main.tscn").instantiate()
  game.set_script(load("res://tests/density_main.gd"))
  game.capture_scenario="status-native-baseline"
  if shape.x==2520:game.fixture_safe_area=Rect2(136,0,2384,1080)
  root.add_child(game);await settle();game.set_process(false)
  var settings=Store.DEFAULTS.duplicate(true);settings.text_scale=1.5
  Settings.apply(settings,game);await settle()
  game._start_mission(id);game._layout();await settle()
  print("BASELINE_STATE id=",id," shape=",shape," stage=water text=",visible_text(game)," arrivals_count=",game.sim.signal_readings().size())
  geometry(game,shape,id,"water")
  await picture("baseline-%d-%d-water"%[shape.x,id])
  var craft=game.mission_hud.fleet.buttons[0]
  await tap(craft.get_global_rect().get_center())
  print("BASELINE_STATE id=",id," shape=",shape," stage=craft text=",visible_text(game)," advanced=",game.advanced_orders)
  geometry(game,shape,id,"craft")
  await picture("baseline-%d-%d-craft"%[shape.x,id])
  await tap(game.mission_hud.extra.inspect.get_global_rect().get_center())
  print("BASELINE_STATE id=",id," shape=",shape," stage=status text=",visible_text(game)," advanced=",game.advanced_orders)
  geometry(game,shape,id,"status")
  await picture("baseline-%d-%d-status"%[shape.x,id])
  await android_back(2);await settle()
  await tap(game.advanced_button.get_global_rect().get_center())
  print("BASELINE_STATE id=",id," shape=",shape," stage=fleet text=",visible_text(game)," advanced=",game.advanced_orders)
  geometry(game,shape,id,"fleet")
  await picture("baseline-%d-%d-fleet"%[shape.x,id])
  await android_back();await settle()
  print("BASELINE_BACK id=",id," shape=",shape," advanced=",game.advanced_orders," screen=",game.screen)
  game.queue_free();await settle()
 Settings.apply(Store.DEFAULTS)
func run():
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with("--capture-dir="):capture_dir=arg.trim_prefix("--capture-dir=")
 DirAccess.make_dir_recursive_absolute(capture_dir)
 for shape in [Vector2i(2520,1080),Vector2i(2184,1968)]:await shape_case(shape)
 print("STATUS NATIVE BASELINE CHECKS 1 FAILURES 0")
 quit(0)
