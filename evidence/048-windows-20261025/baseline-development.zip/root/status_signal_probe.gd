extends SceneTree
# Bounded source-known signal acquisition probe for the UI test fixture.
const Sim=preload("res://src/simulation/simulation.gd")
func _initialize():
 for id in [6,9,11]:
  var s=Sim.new();s.start(id,"endurance")
  s.paused=false
  var first=-1.0
  for n in 3600:
   s.advance(Sim.STEP)
   if s.signal_readings().size()>0:
    first=s.elapsed;break
   if not s.outcome.is_empty():break
  s.paused=true
  print("SIGNAL_PROBE id=",id," first=",first," count=",s.signal_readings().size()," hull=",s.hull," outcome=",s.outcome," valid=",Sim.valid_snapshot(s.snapshot()))
 print("STATUS SIGNAL PROBE CHECKS 1 FAILURES 0")
 quit(0)
