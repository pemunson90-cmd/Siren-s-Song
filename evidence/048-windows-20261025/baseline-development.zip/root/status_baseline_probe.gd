extends SceneTree
const Sim=preload("res://src/simulation/simulation.gd")
const IDS=[0,6,7,9,11,22,24,27,28,29]
func _initialize():
 for id in IDS:
  var s=Sim.new();s.start(id,"endurance")
  var fresh=s.camera_context().get("text","")
  var initial_message=s.message
  var selected=s.command("select",{"unit":0})
  var context=s.camera_context()
  var sites=s.observable_sites().map(func(o):return {"name":o.get("name",""),"kind":o.get("kind",""),"optional":o.get("optional",false),"captured":o.get("captured",false),"stage":o.get("stage","")})
  var choir=s.choir_context()
  var glass=s.glass_context()
  var choir_actions=[]
  for action in choir.get("actions",{}):choir_actions.append({"action":action,"reason":choir.actions[action].get("reason","")})
  var glass_actions=[]
  for action in glass.get("actions",{}):glass_actions.append({"action":action,"reason":glass.actions[action].get("reason","")})
  var corridors=s.extraction_corridors().map(func(c):return {"name":c.get("name",""),"available":c.get("available",false),"withdrawal":c.get("withdrawal",false)})
  print("STATUS_BASE id=",id," initial_context=",fresh," initial_message=",initial_message," selected=",selected," selected_context=",context.get("text","")," selected_message=",s.message," phase=",s.mission.get("phase","")," expedition_revision=",s.mission.get("expedition_revision",-1)," facts=",s.mission.get("expedition_facts",{}).keys()," sites=",sites," choir_sites=",choir.get("sites",[]).map(func(x):return x.get("id",""))," choir_actions=",choir_actions," glass_actions=",glass_actions," corridors=",corridors," arrivals=",s.signal_readings().size())
 print("STATUS BASELINE CHECKS 1 FAILURES 0");quit(0)
