extends "res://tests/status_text_ui_tests.gd"
const View=preload("res://src/presentation/status_text/status_view.gd")
const Layout=preload("res://src/presentation/status_text/status_layout.gd")
func run():
 var game=await make_game(24,Vector2i(2520,1080))
 var before=game.sim.snapshot()
 for shape in [Vector2i(2520,1080),Vector2i(2184,1968),Vector2i(2520,1080)]:
  game.fixture_safe_area=Rect2(136,0,2384,1080) if shape.x==2520 else Rect2()
  root.size=shape;await settle();game._layout();await settle()
  for page in ["craft","fleet","tools","acoustics"]:
   game.mission_hud.open(page);await settle()
   var h=game.mission_hud
   var positions=h.ring_buttons.map(func(b):return b.position)
   for n in 6:game._refresh();await settle()
   check(range(h.ring_buttons.size()).all(func(i):return h.ring_buttons[i].position.distance_to(positions[i])<0.001),"refresh stays within 0.001 pixel "+page+str(shape))
   ring_geometry(game,"repeat "+page+str(shape))
   for i in h.ring_buttons.size():
    var angle=-PI/2+TAU*i/h.ring_buttons.size()
    var local=View.radial_point(h,angle,h.ring_radius)
    var point=h.global_position+h.center+local
    check(h.sector_at(point)==h.ring_buttons[i],"drawn wedge center maps to its same action "+page+str(i))
    check(View.radial_local(h,local).is_equal_approx(Vector2.from_angle(angle)*h.ring_radius),"draw/hit transforms invert "+page+str(i))
   if page=="fleet":check(View.captions(h,["title","fleet"]).count(Status.arrivals_hint(0))==1,"refresh has exactly one arrivals caption")
  game.mission_hud.open("signals");await settle()
  for n in 6:game._refresh();await settle()
  check(game.mission_hud.instrument_info.text.count(Status.arrivals_hint(0))==1,"signals refresh does not duplicate hint")
  sheet_geometry(game,"repeated signals "+str(shape))
 check(game.sim.snapshot()==before,"resize/refresh and public pages preserve simulation snapshot")
 game.mission_hud.open("fleet");await settle()
 Table.enabled=false;game._refresh();game._layout();await settle()
 check(not game.mission_hud.has_meta(View.AXES),"off switch clears stretched axes")
 var hud=game.mission_hud
 for i in hud.ring_buttons.size():
  var expected=hud.center+Vector2.from_angle(-PI/2+TAU*i/hud.ring_buttons.size())*hud.ring_radius-hud.ring_buttons[i].size/2
  check(hud.ring_buttons[i].position.is_equal_approx(expected),"off switch restores circular control position "+str(i))
 Table.enabled=true;Layout.enabled=true;game.queue_free();await settle()
 print("INDEPENDENT STATUS REFRESH CHECKS ",checks," FAILURES ",failures)
 quit(1 if failures else 0)
