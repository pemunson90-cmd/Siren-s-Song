$ErrorActionPreference='Stop'
$repo='C:/Users/Archi/Documents/Codex/2026-10-24/you-are-codex-the-implementation-worker/048-hud-sameness'
$ev='C:/Users/Archi/Documents/Codex/2026-10-24/you-are-codex-the-implementation-worker/048-evidence/independent-fa13'
. ($repo+'/scripts/toolchain/win/common.ps1')
# Preserve the shared runner, using a hidden launch instead of a console window.
$logged=(Get-Command Invoke-GodotLogged).Definition.Replace('-NoNewWindow','-WindowStyle Hidden')
Set-Item Function:Invoke-GodotLogged ([scriptblock]::Create($logged))
$exe=Assert-GodotExe
$rows=Read-SuiteRegistry
$root=$ev+'/data-'+[guid]::NewGuid().ToString('N')
$suites=@('import','run_tests','status_text_tests','status_text_ui_tests','radial_hud_tests','playfield_hud_tests','fleet_instruments_ui_tests','expedition_instruments_ui_tests','campaign_instruments_ui_tests','lock_warning_ui_tests','status_text_ui_native')
$results=@()
foreach($name in $suites){
 $native=$name -eq 'status_text_ui_native'
 $suite=if($native){'status_text_ui_tests'}else{$name}
 $args=@('--path',($repo+'/game'),'--audio-driver','Dummy')
 if($native){$args+=@('--rendering-method','gl_compatibility')}else{$args+=@('--headless')}
 if($suite -eq 'import'){$args+=@('--editor','--import')}else{$args+=@('--script',('res://tests/'+$suite+'.gd'))}
 if($native){$args+=@('--',('--capture-dir='+$ev+'/captures'))}
 $log=$ev+'/'+$name+'.log';$isolation=$root+'/'+$name
 Write-Output ('START '+$name)
 $watch=[Diagnostics.Stopwatch]::StartNew()
 $exit=Invoke-GodotLogged -GodotArgs $args -Log $log -TimeoutSec 240 -IsolatedRoot $isolation
 $watch.Stop()
 $prefix=if($suite -eq 'import'){''}else{($rows | Where-Object {$_.Name -eq $suite}).Prefix}
 $parsed=Test-GodotLog -Log $log -Prefix $prefix -RequireSummary ($suite -ne 'import')
 $failLines=@(Get-Content $log | Where-Object {$_ -match '^FAIL '})
 $ok=$exit -eq 0 -and $parsed.Problems.Count -eq 0 -and $failLines.Count -eq 0
 $result=[pscustomobject]@{suite=$name;exit=$exit;pass=$ok;seconds=[math]::Round($watch.Elapsed.TotalSeconds,3);summary=$parsed.Summary;checks=$parsed.Checks;failures=$parsed.Failures;errors=$parsed.Problems;failLines=$failLines;log=$log;userdata=$isolation;command=($exe+' '+(ConvertTo-ArgString $args))}
 $results+=$result
 $results | ConvertTo-Json -Depth 6 | Set-Content ($ev+'/results.json') -Encoding UTF8
 Write-Output ($result | ConvertTo-Json -Compress -Depth 5)
 if(-not $ok){throw ('CHECK_FAILED '+$name)}
}