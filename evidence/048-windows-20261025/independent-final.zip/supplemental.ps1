$ErrorActionPreference='Stop'
$repo='C:/Users/Archi/Documents/Codex/2026-10-24/you-are-codex-the-implementation-worker/048-hud-sameness'
$ev='C:/Users/Archi/Documents/Codex/2026-10-24/you-are-codex-the-implementation-worker/048-evidence/independent-fa13'
. ($repo+'/scripts/toolchain/win/common.ps1')
Set-Item Function:Invoke-GodotLogged ([scriptblock]::Create((Get-Command Invoke-GodotLogged).Definition.Replace('-NoNewWindow','-WindowStyle Hidden')))
$results=@();$data=$ev+'/supplemental-data-'+[guid]::NewGuid().ToString('N')
foreach($name in @('import-e1','refresh-native')){
 $args=@('--path',($repo+'/game'),'--audio-driver','Dummy')
 if($name -eq 'import-e1'){$args+=@('--headless','--editor','--import');$prefix=''}else{$args+=@('--rendering-method','gl_compatibility','--script',($ev+'/refresh_probe.gd'));$prefix='INDEPENDENT STATUS REFRESH'}
 $timer=[Diagnostics.Stopwatch]::StartNew()
 $exit=Invoke-GodotLogged -GodotArgs $args -Log ($ev+'/'+$name+'.log') -TimeoutSec 120 -IsolatedRoot ($data+'/'+$name)
 $timer.Stop();$parsed=Test-GodotLog -Log ($ev+'/'+$name+'.log') -Prefix $prefix -RequireSummary ($name -ne 'import-e1')
 $item=[pscustomobject]@{suite=$name;head=(git -C $repo rev-parse HEAD);exit=$exit;seconds=$timer.Elapsed.TotalSeconds;summary=$parsed.Summary;errors=$parsed.Problems;checks=$parsed.Checks;failures=$parsed.Failures;log=($ev+'/'+$name+'.log');command=((Get-GodotConsoleExe)+' '+(ConvertTo-ArgString $args));userdata=($data+'/'+$name)}
 $results+=$item;$results | ConvertTo-Json -Depth 6 | Set-Content ($ev+'/supplemental-results.json') -Encoding UTF8
 $item | ConvertTo-Json -Depth 5 -Compress
 if($exit -ne 0 -or $parsed.Problems.Count -gt 0){throw ('SUPPLEMENT_FAILED '+$name)}
}