"""Read-only GitHub log retrieval when the connector cannot carry a large log.
Credentials stay in memory and are never printed or forwarded to the log host.
"""
import collections
import datetime
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import urllib.error
import urllib.parse
import urllib.request

env = dict(os.environ, GIT_TERMINAL_PROMPT="0", GCM_INTERACTIVE="Never")
credential = subprocess.run(
    ["git", "credential", "fill"],
    input="url=https://github.com/pemunson90-cmd/Siren-s-Song.git\n\n",
    text=True, capture_output=True, env=env, timeout=30,
)
if credential.returncode:
    raise SystemExit("Existing noninteractive GitHub authentication unavailable")
fields = dict(line.split("=", 1) for line in credential.stdout.splitlines() if "=" in line)
token = fields.get("password", "")
if not token:
    raise SystemExit("Existing GitHub authentication did not provide access")

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None

url = "https://api.github.com/repos/pemunson90-cmd/Siren-s-Song/actions/jobs/121029451911"
if "--status" not in sys.argv:
    url += "/logs"
request = urllib.request.Request(url, headers={
    "Authorization": "Bearer " + token,
    "User-Agent": "SirenSong-Codex-ReadOnly",
    "Accept": "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
    "Cache-Control": "no-cache",
})
try:
    response = urllib.request.build_opener(NoRedirect()).open(request, timeout=45)
except urllib.error.HTTPError as error:
    if error.code not in (301, 302, 303, 307, 308):
        raise SystemExit("GitHub log request returned HTTP " + str(error.code))
    location = error.headers.get("Location", "")
    parsed = urllib.parse.urlsplit(location)
    hostname = parsed.hostname or ""
    if parsed.scheme != "https" or not (
        hostname.endswith(".blob.core.windows.net")
        or hostname.endswith(".githubusercontent.com")
        or hostname.endswith(".actions.githubusercontent.com")
    ):
        raise SystemExit("GitHub log redirect host requires inspection")
    # This new request deliberately has no GitHub Authorization header.
    response = urllib.request.urlopen(
        urllib.request.Request(location, headers={"User-Agent": "SirenSong-Codex-ReadOnly"}),
        timeout=45,
    )
if "--status" in sys.argv:
    with response:
        data = json.load(response)
    print(json.dumps({
        key: data.get(key) for key in [
            "id", "run_id", "head_sha", "name", "status", "conclusion",
            "started_at", "completed_at",
        ]
    }))
    print(json.dumps([
        {key: step.get(key) for key in ["number", "name", "status", "conclusion", "started_at", "completed_at"]}
        for step in data.get("steps", [])
    ]))
    raise SystemExit(0)
stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%d-%H%M%S")
path = pathlib.Path(__file__).with_name("ci-c4-direct-" + stamp + ".log")
with response, path.open("wb") as target:
    shutil.copyfileobj(response, target, length=1024 * 1024)
summaries = collections.deque(maxlen=6)
problems = collections.deque(maxlen=5)
last = ""
with path.open(encoding="utf-8-sig", errors="replace") as source:
    for line in source:
        if line.strip():
            last = line[:220].rstrip()
        if re.search(r"CHECKS \d+ FAILURES \d+", line):
            summaries.append(line.rstrip())
        if "\x1b[36;1m" not in line and re.search(r"SCRIPT ERROR:|\bFAIL[: ]", line):
            problems.append(line.rstrip())
print("Downloaded log bytes:", path.stat().st_size)
for line in summaries:
    print(line)
for line in problems:
    print(line)
print("Latest log line:", last)
