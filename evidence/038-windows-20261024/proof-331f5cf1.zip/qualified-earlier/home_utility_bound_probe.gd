extends "res://tests/ops_home_ui_tests.gd"
# Geometry bound only: model the two optional ending/archive utility rows.
func run():
 root.size=Vector2i(2520,1080);await settle()
 var game=load("res://scenes/main.tscn").instantiate()
 game.set_script(load("res://tests/density_main.gd"));game.capture_scenario="runtime-test"
 root.add_child(game);await settle();game.set_process(false)
 game.completed=range(6);game.unlocked=5;game.active_started=false
 game.expedition={"version":1,"route":"deep","routes":["deep"],"facts":{},"completed":range(6,32)}
 for scale in [1.,1.5]:
  var prefs=Prefs.SettingsStore.DEFAULTS.duplicate();prefs.text_scale=scale
  Prefs.apply(prefs,game);await settle();game._show_campaign();await settle()
  game._button(game.panel_box,"VIEW CAMPAIGN ENDING",func():pass,"probe_ending")
  game._button(game.panel_box,"REVIEW FIELD RECORDS",func():pass,"probe_evidence")
  game._layout();await settle()
  var ratio=game.panel_box.size.y/game.scroll.size.y
  print("HOME UTILITY BOUND scale=",scale," ratio=",ratio)
  check(ratio<3.,"two optional utility rows retain the under-three-screen bound")
 game.queue_free();await settle()
 print("OPS HOME BOUND CHECKS ",checks," FAILURES ",failures);quit(1 if failures else 0)
