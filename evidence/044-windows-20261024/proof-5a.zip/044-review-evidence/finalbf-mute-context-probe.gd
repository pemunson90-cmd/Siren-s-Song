extends SceneTree
const Prefs=preload("res://src/presentation/frontend/frontend_settings.gd")
const Reach=preload("res://src/presentation/frontend/menu_reach.gd")
var checks=0
var failures=0
func check(ok,label):
 checks+=1
 if not ok:failures+=1;printerr("FAIL ",label)
 print("MUTE_CONTEXT ",label," master=",Prefs.current.master," ok=",ok)
func _initialize():call_deferred("run")
func settle():
 for n in 6:await process_frame
func run():
 root.size=Vector2i(1280,720)
 var game=load("res://scenes/main.tscn").instantiate();game.capture_scenario="runtime-test";game.settings_path="user://mute-context-probe.json";root.add_child(game);await settle();game.set_process(false)
 Prefs.apply(Prefs.SettingsStore.DEFAULTS,game)
 game._settings_menu();await settle()
 var front=game.get_node("Frontend");front._set_value("master",.35);front._toggle_mute();await settle()
 check(Prefs.current.master==0.,"operations mute")
 front._return();await settle();Reach.open(game,"title");await settle();front=game.get_node("Frontend");front._settings_screen();await settle()
 front._toggle_mute();await settle();check(is_equal_approx(Prefs.current.master,.35),"operations mute then title unmute")
 front._set_value("master",.6);front._set_value("master",0.);await settle();check(Prefs.current.master==0.,"title slider zero")
 front._return();await settle();front._return();await settle();game._settings_menu();await settle();front=game.get_node("Frontend")
 front._toggle_mute();await settle();check(is_equal_approx(Prefs.current.master,.6),"title slider zero then operations unmute")
 front._return();game.queue_free();await settle()
 print("MUTE CONTEXT CHECKS ",checks," FAILURES ",failures);quit(1 if failures else 0)
