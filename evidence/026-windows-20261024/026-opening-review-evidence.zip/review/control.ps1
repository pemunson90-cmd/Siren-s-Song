param([string]$Commands)
$base=$PSScriptRoot
foreach($command in ($Commands | ConvertFrom-Json)) {
 $previous=(Get-Content "$base/state.json" -Raw | ConvertFrom-Json).serial
 $command | ConvertTo-Json -Compress | Set-Content "$base/command.json"
 for($n=0;$n -lt 200;$n++) { Start-Sleep -Milliseconds 100; try { $state=Get-Content "$base/state.json" -Raw | ConvertFrom-Json; if($state.serial -gt $previous){break} }catch{} }
 $state | Select-Object serial,screen,mission,paused,outcome,message,labels,@{n="actions";e={($_.buttons | ForEach-Object {$_.id+"="+$_.text}) -join "; "}},sites,craft | ConvertTo-Json -Depth 8 -Compress
}

