$env:APPDATA='C:/Users/Archi/Documents/Codex/2026-10-23/continue-as-codex-on-the-siren/work/026-review/appdata'
$env:LOCALAPPDATA=$env:APPDATA
New-Item -ItemType Directory -Force $env:APPDATA | Out-Null
$p=Start-Process -FilePath 'C:/Users/Archi/.cache/sirens-song-toolchain/win/Godot_v4.6.3-stable_win64_console.exe' -ArgumentList @('--path','C:/Users/Archi/Documents/Codex/2026-10-23/continue-as-codex-on-the-siren/work/landmarks-merge/game','--rendering-method','gl_compatibility','--audio-driver','Dummy','--script','C:/Users/Archi/Documents/Codex/2026-10-23/continue-as-codex-on-the-siren/work/026-review/review.gd') -WindowStyle Hidden -RedirectStandardOutput 'C:/Users/Archi/Documents/Codex/2026-10-23/continue-as-codex-on-the-siren/work/026-review/native.log' -RedirectStandardError 'C:/Users/Archi/Documents/Codex/2026-10-23/continue-as-codex-on-the-siren/work/026-review/native-error.log' -PassThru
$p.WaitForExit()
