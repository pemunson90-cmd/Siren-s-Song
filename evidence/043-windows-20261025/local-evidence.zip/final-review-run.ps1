$ErrorActionPreference='Stop'
$repo='C:/Users/Archi/Documents/Codex/2026-10-24/you-are-codex-the-implementation-worker/043-save2'
$evidence='C:/Users/Archi/Documents/Codex/2026-10-24/you-are-codex-the-implementation-worker/043-evidence'
$exe='C:/Users/Archi/.cache/sirens-song-toolchain/win/Godot_v4.6.3-stable_win64_console.exe'
$runRoot=$evidence+'/final-review-data/architect-f8da8ec3-'+[guid]::NewGuid().ToString('N')
$env:SIRENS_043_CAPTURE_DIR=''
$results=@()
$suites=@('import','run_tests','save2_storage_tests','save2_fork_tests','save2_ui_tests','save_profiles_tests','fix2_save_tests','fix2_state_tests','fix2_save_ui_tests','save_profiles_ui_tests','endings_photo_ui_tests','menu_reach_ui_tests','settings_lifecycle_ui_tests','ops_home_ui_tests')
$native=@('save2_ui_tests','fix2_save_ui_tests','save_profiles_ui_tests','endings_photo_ui_tests','menu_reach_ui_tests','settings_lifecycle_ui_tests','ops_home_ui_tests')
foreach($suite in $suites) {
 $env:APPDATA=$runRoot+'/'+$suite+'/Roaming';$env:LOCALAPPDATA=$runRoot+'/'+$suite+'/Local'
 New-Item -ItemType Directory -Force -Path $env:APPDATA,$env:LOCALAPPDATA | Out-Null
 $log=$evidence+'/final-review-architect-'+$suite+'.log';$err=$evidence+'/final-review-architect-'+$suite+'.stderr.log'
 $args=@('--path',('"'+$repo+'/game"'),'--audio-driver','Dummy')
 if($suite -in $native){$args+=@('--rendering-method','gl_compatibility')}else{$args+=@('--headless')}
 if($suite -eq 'import'){$args+=@('--editor','--import')}else{$args+=@('--script',('res://tests/'+$suite+'.gd'))}
 Write-Output ('START '+$suite+' '+$env:APPDATA)
 $p=Start-Process -FilePath $exe -ArgumentList $args -WindowStyle Hidden -PassThru -RedirectStandardOutput $log -RedirectStandardError $err
 $null=$p.Handle
 if(-not $p.WaitForExit(480000)){$p.Kill();$p.WaitForExit();$code=-1}else{$p.WaitForExit();$code=$p.ExitCode}
 $lines=@(Get-Content -LiteralPath $log)+@(Get-Content -LiteralPath $err)
 $issues=@($lines | Where-Object {$_ -match 'SCRIPT ERROR:|(^|\s)ERROR:|resources still in use|ObjectDB instances leaked|^FAIL '})
 $summaries=@($lines | Where-Object {$_ -match 'CHECKS \d+ FAILURES \d+'})
 $badSummary=@($summaries | Where-Object {$_ -notmatch 'FAILURES 0\s*$'})
 $ok=$code -eq 0 -and $issues.Count -eq 0 -and $badSummary.Count -eq 0 -and ($suite -eq 'import' -or $summaries.Count -gt 0)
 $item=[pscustomobject]@{suite=$suite;exit=$code;pass=$ok;summary=$summaries;errors=$issues;log=$log;stderr=$err;userdata=$env:APPDATA}
 $results+=$item
 $results | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath ($evidence+'/final-review-architect-results.json') -Encoding UTF8
 Write-Output ($item | ConvertTo-Json -Compress -Depth 4)
}
