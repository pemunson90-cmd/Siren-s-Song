extends SceneTree
func _initialize():call_deferred("run")
func run():
 var path="user://blocked-cold.save"
 DirAccess.make_dir_recursive_absolute(path+".save2")
 var file=FileAccess.open(path+".save2/transaction",FileAccess.WRITE);file.store_buffer(PackedByteArray([1,2,3]));file.close()
 var game=load("res://scenes/main.tscn").instantiate()
 game.store.path=path;game.settings_path="user://blocked-settings.json"
 root.add_child(game)
 for n in 4:await process_frame
 game.set_process(false)
 print("BLOCKED_COLD mission=",game.sim.mission," units=",game.sim.units.size()," screen=",game.screen," warning=",game.archive_warning)
 game.queue_free()
 for n in 3:await process_frame
 quit()
