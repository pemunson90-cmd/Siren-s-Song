extends SceneTree
const C=preload("res://src/persistence/save_states/save2_controller.gd")
const T=preload("res://src/persistence/save_states/save2_table.gd")
class Host extends RefCounted:
 var completed=[]
 var expedition={}
 var active_started=false
 var archive_warning=""
 var store=load("res://src/persistence/save_store.gd").new()
 var sim=load("res://src/simulation/simulation.gd").new()
func _initialize():call_deferred("run")
func run():
 var h=Host.new();h.store.path="user://off-probe.save";h.sim.start(0)
 var original=C.ensure_state(h).duplicate(true)
 T.enabled=false;h.active_started=true
 var saved={"version":2,"unlocked":0,"completed":[],"settings":{},"upgrade":"endurance","active":h.sim.snapshot()}
 C.write(h,saved)
 print("OFF_PROBE valid=",h.store.valid(saved)," actual_active=",h.active_started," saved_between=",saved[T.STATE].between," launch_unchanged=",saved[T.STATE].launch_id==original.launch_id)
 T.enabled=true
 var fresh=Host.new();fresh.store.path=h.store.path;fresh.sim.start(0);fresh.active_started=true
 C.restore(fresh,saved)
 print("OFF_PROBE reenabled_active=",fresh.active_started," expected=true")
 quit()
