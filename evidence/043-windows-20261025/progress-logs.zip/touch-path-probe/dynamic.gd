extends SceneTree
func _initialize():
 Input.emulate_mouse_from_touch=false
 print("DYNAMIC before=",Input.emulate_mouse_from_touch)
 ProjectSettings.set_setting("input_devices/pointing/emulate_mouse_from_touch",true)
 print("DYNAMIC after_project_setting=",Input.emulate_mouse_from_touch)
 Input.emulate_mouse_from_touch=true
 print("DYNAMIC after_input_property=",Input.emulate_mouse_from_touch)
 quit()
