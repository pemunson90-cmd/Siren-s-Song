extends SceneTree
var count=0
var gui=[]
var mode=""
func _initialize():call_deferred("run")
func settle():
 for n in 4:await process_frame
func touch(down):
 var e=InputEventScreenTouch.new();e.index=0;e.position=Vector2(150,150);e.pressed=down;return e
func mouse(down):
 var e=InputEventMouseButton.new();e.device=InputEvent.DEVICE_ID_EMULATION;e.position=Vector2(150,150);e.global_position=e.position;e.button_index=MOUSE_BUTTON_LEFT;e.pressed=down;return e
func run():
 root.size=Vector2i(800,600)
 var b=Button.new();b.text="Probe";b.position=Vector2(100,100);b.size=Vector2(200,100);root.add_child(b)
 b.pressed.connect(func():count+=1)
 b.gui_input.connect(func(e):
  if e is InputEventScreenTouch or e is InputEventMouseButton:gui.append(e.get_class()+":"+str(e.pressed)+":"+str(e.device))
 )
 await settle()
 print("ENV display=",DisplayServer.get_name()," engine=",Engine.get_version_info().string," user=",OS.get_user_data_dir()," emulate=",Input.emulate_mouse_from_touch)
 for m in ["push_touch","parse_touch","push_interleaved","push_touch_then_mouse"]:
  mode=m;count=0;gui=[]
  if m=="push_touch" or m=="parse_touch":
   for down in [true,false]:
    if m=="parse_touch":Input.parse_input_event(touch(down));Input.flush_buffered_events()
    else:root.push_input(touch(down),true)
    await process_frame
  elif m=="push_interleaved":
   for down in [true,false]:
    root.push_input(touch(down),true);await process_frame
    root.push_input(mouse(down),true);await process_frame
  else:
   for down in [true,false]:root.push_input(touch(down),true);await process_frame
   for down in [true,false]:root.push_input(mouse(down),true);await process_frame
  await settle()
  print("RESULT ",mode," count=",count," gui=",gui)
 quit()
