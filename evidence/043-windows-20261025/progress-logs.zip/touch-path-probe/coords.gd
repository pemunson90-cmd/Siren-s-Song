extends SceneTree
var count=0
func _initialize():call_deferred("run")
func settle():
 for n in 4:await process_frame
func run():
 Input.emulate_mouse_from_touch=true
 root.size=Vector2i(2520,1080)
 var b=Button.new();b.text="Coordinates";b.position=Vector2(300,300);b.size=Vector2(100,100);root.add_child(b)
 b.pressed.connect(func():count+=1)
 await settle()
 print("COORD window=",root.size," viewport=",root.get_visible_rect()," final_transform=",root.get_final_transform()," content_scale=",root.content_scale_size)
 var local_point=b.get_global_rect().get_center()
 for translated in [false,true]:
  count=0
  var point=root.get_final_transform()*local_point if translated else local_point
  for down in [true,false]:
   var e=InputEventScreenTouch.new();e.index=0;e.position=point;e.pressed=down;Input.parse_input_event(e);Input.flush_buffered_events();await process_frame
  await settle()
  print("COORD translated=",translated," point=",point," count=",count)
 quit()
